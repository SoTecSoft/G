# para criar projeto em django, necessita de digitar algo assim -> "django-admin startproject project ."
# C:\Users\yytol\PycharmProjects\pythonProject6\ProjectStude\A1\A2\A3\B1\B2\B3\C1\C2\C3\Anotacao\DPython\A1\B1\C\A1
#C:\Users\yytol\PycharmProjects\pythonProject6\ProjectStude\A1\A2\A3\B1\B2\B3\C1\C2\C3\Anotacao\DPython\A1\B1\C\A1
# C:\Users\yytol\PycharmProjects\pythonProject6\ProjectStude\A1\A2\A3\B1\B2\B3\C1\C2\C3\Anotacao\DPython\A1\B1\C\A1
