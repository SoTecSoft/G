import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.GeradorT.NeretoNite as pgtnn

dG = pgtnn.GeretoNiu()

a = "oi"
b = ['a']
dG.set_palavras(a)
#dG.set_iniciarAssociacaoGeral_A2()
dG.set_iniciarAssociacao()
dG.set_iniciarAssociacao2()
dG.set_stgurment(1)
print(dG.get_stgurment())
print(dG.dGl.dAssociacaoDeCadaCaractere_2_extra2)