import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.CriptKeyfria.A1.B1.C1.UseT.IkDek as dPK

dcio = dPK.dc_dk()

dcio.set_init_gamex()