import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.CriptKeyfria.AFL as gGel
import random as rdT

class GeretoNiu:
    def __init__(self):
        self.dListDeTraducao = []
        self.dListDeAssociacoes = []
        self.dContList = []
        self.dNumAle = []
        # g2
        self.dGl = gGel.TiouKey()
        self.dGl.set_giu()
        # g2;
        self.dPalavras = ''
        self.dPalavras_Extra2 = ''
        self.dPalavras_Extra3 = ''
        self.dPalavras_GeralA1 = []

        self.dContOPs = 0
        self.dContOPs_extra = 0
        #-<
        self.dContOPs_2 = 0
        self.dContOPs_2_extra2 = 0
        ##-<
        self.dContOPs_3 = 0
        self.dContOPs_3_extra2 = 0
        #>-
        self.dContOPs_4 = 0
        self.dContOPs_4_extra2 = 0

        #!!
        self.dContOXP = 0
        self.dContOXP_extra2 = 0

        #!! extra
        self.dContOXP2 = 0
        self.dContOXP2_extra2 = 0
        self.dContOXP2_extr3 = 0

        self.dRdm = rdT.Random()

        self.dTypeTex = 0
        self.dPalavras_GeralA2 = []

    def set_palavras(self, fPalavras):
        self.dPalavras = fPalavras

    def set_iniciarAssociacao(self):
        # sim
        for dpPalavras in self.dPalavras:
            self.dContOPs = self.dContOPs_extra
            self.dContOPs_extra += 1
            self.dContOPs_2_extra2 = 0
            for dpAssociacoes in self.dGl.dDeCadaCaractre:
                self.dContOPs_2 = self.dContOPs_2_extra2
                self.dContOPs_2_extra2 += 1
                if self.dGl.dDeCadaCaractre[self.dContOPs_2] in self.dPalavras[self.dContOPs]:
                    self.dContList.append(self.dContOPs_2)

        # sim;
        ### n
        """
        for dklopTX in self.dContList:
            self.dContOPs_3 += self.dContOPs_3_extra2
            self.dContOPs_3_extra2 += 1
            self.dContOXP = self.dContList[self.dContOPs]
            self.dPalavras_Extra3 += self.dGl.dCaracteresEspeciais[self.dContOXP]

            for OPSX in self.dGl.dAssociacaoDeCadaCaractere_2_extra2[self.dContOXP]:
                self.dContOXP2 = self.dRdm.randint(0, len(self.dGl.dAssociacaoDeCadaCaractere_2_extra2[self.dContOXP]))
                self.dPalavras_Extra2 += self.dGl.dAssociacaoDeCadaCaractere_2_extra2[self.dContOXP][self.dContOXP2]

        self.dListDeAssociacoes.append(self.dPalavras_Extra2)
        self.dListDeTraducao.append(self.dPalavras_Extra3)
        """
        ### n;

    def set_iniciarAssociacao2(self):
        for dklopTX in self.dContList:
            self.dContOPs_3 = self.dContOPs_3_extra2 # era '+='
            self.dContOPs_3_extra2 += 1
            self.dContOXP = self.dContList[self.dContOPs_3] # era self.dContOPs
            self.dPalavras_Extra3 += self.dGl.dCaracteresEspeciais[self.dContOXP]

            for OPSX in self.dGl.dAssociacaoDeCadaCaractere_2_extra2[self.dContOXP]:
                self.dContOXP2 = self.dRdm.randint(0, len(self.dGl.dAssociacaoDeCadaCaractere_2_extra2[self.dContOXP]))
                self.dPalavras_Extra2 += self.dGl.dAssociacaoDeCadaCaractere_2_extra2[self.dContOXP][self.dContOXP2]

    """
    def set_traduzir(self):
    """

    def set_iniciarAssociacaoGeral_A2(self):
        self.set_iniciarAssociacao()
        self.set_iniciarAssociacao2()
        self.dListDeTraducao.append(self.dPalavras_Extra3)
        self.dListDeAssociacoes.append(self.dPalavras_Extra2)


    def set_stgurment(self, fTipo):
        self.dTypeTex = fTipo
        if self.dTypeTex == 1:
            self.dPalavras_GeralA2 = self.dPalavras_Extra3
        if self.dTypeTex == 2:
            self.dPalavras_GeralA2 = self.dPalavras_Extra2

    def get_stgurment(self):
        return self.dPalavras_GeralA2

    def set_deleteVar_Rpex2(self):
        self.dListDeTraducao = []
        self.dListDeAssociacoes = []
        self.dContList = []
        self.dNumAle = []

        self.dPalavras = ''
        self.dPalavras_Extra2 = ''
        self.dPalavras_Extra3 = ''
        self.dPalavras_GeralA1 = []

        self.dContOPs = 0
        self.dContOPs_extra = 0
        # -<
        self.dContOPs_2 = 0
        self.dContOPs_2_extra2 = 0
        ##-<
        self.dContOPs_3 = 0
        self.dContOPs_3_extra2 = 0
        # >-
        self.dContOPs_4 = 0
        self.dContOPs_4_extra2 = 0

        # !!
        self.dContOXP = 0
        self.dContOXP_extra2 = 0

        # !! extra
        self.dContOXP2 = 0
        self.dContOXP2_extra2 = 0
        self.dContOXP2_extr3 = 0

        self.dRdm = rdT.Random()

        self.dTypeTex = 0
        self.dPalavras_GeralA2 = ''