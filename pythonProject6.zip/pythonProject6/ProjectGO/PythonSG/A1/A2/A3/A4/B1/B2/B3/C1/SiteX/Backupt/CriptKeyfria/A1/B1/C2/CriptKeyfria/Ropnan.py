import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.CriptKeyfria.AFL as qfl

know = qfl.TiouKey()

class LangNew:
    def __init__(self):
        self.dOpk = ''
        self.dargumnt_2 = ''
        self.dargumnt_2_extra2 = ''
        self.dIdxAcao = ''
        self.dcont2 = 0
        self.dlnow = qfl.TiouKey()
        #self.dlnow.set_giu()
        self.donList_2 = []
        self.diknum_2 = 0
        self.dretrn_ol = 0
        self.dEscrever = False
        self.descolhaT = 0
        self.ddrumgNum = 0
        self.dCaractUm_2 = 0
        self.dDeEscreverValor = ''
        self.dargumnt_2_extra3 = ''
        self.dklop = []
        self.dklop_escrev = []
        self.dPodeContarBool = True
        self.djCont = 0
        self.dGuardNumb = 0
        self.dCotUil = 0
        self.dCotUil_2 = 0
        self.dCoutUil = 0
        self.dOUIX = ''
    def set_confgInit_UIOP1(self):
        self.dlnow.set_giu()

    def set_passoTraducao(self, opk, escrever=False):
        self.dOpk = opk
        self.dEscrever = escrever

    def get_obterParaTraduzir(self):
        for drP in range(len(self.dlnow.dCaracteresEspeciais)+self.dGuardNumb):
            glp = self.dlnow.dDeCadaCaractre[self.diknum_2]

            self.diknum_2 = self.dcont2
            self.dcont2 += 1
            """
            if self.dPodeContarBool == True:
                self.dcont2 += 1

            if self.dPodeContarBool == False:
                self.djCont += 1
                self.dGuardNumb = self.djCont
                if self.djCont == 1:
                    self.djCont = 0
                    #break
                    self.dPodeContarBool = True
            """

            # caso precise, tire os: break;
            if self.dOpk == glp:
                if self.dEscrever == False:
                    #self.dklop.append(self.dlnow.dCaracteresEspeciais[self.diknum_2])
                    self.dklop.append(glp)


                else:
                    """
                    for fyx in glp:
                        #self.ddrumgNum += 1
                        self.dargumnt_2_extra2 += glp[self.ddrumgNum]
                        self.ddrumgNum += 1
                        if self.dargumnt_2_extra2.isnumeric():
                            self.dDeEscreverValor += self.dargumnt_2_extra2

                    ###
                    #self.dklop_escrev.append(self.dlnow.dDeCadaCaractre[self.diknum_2])

                    #break
                    """
                    for dfX in glp:
                        if dfX in '=':
                            if self.dCoutUil == 1:
                                self.dOUIX += dfX
                            else:
                                self.dCoutUil += 1





            else:
                if self.dEscrever == False:
                    if self.dOpk.isnumeric():
                        self.dklop.append(self.dOpk)


                        #self.dPodeContarBool = False

                        break
                    if self.dOpk == ' ':
                        self.dklop.append(self.dOpk) #kdTrue

                        #self.dPodeContarBool = False
                else:
                    if self.dOpk == ' ':
                        self.dklop_escrev.append(' ')


                        #self.dPodeContarBool = False

    def set_deleteOwniu(self):
        self.dklop = []

    def get_translate_(self):
        return self.dklop

    def get_translate_2(self):
        return self.dklop_escrev

    def set_deleteOwniu(self):
        self.dklop_escrev = []

    def set_mudarX(self, mudaX):
        self.dlnow.set_mudar(mudaX)



class Ink_UopNew:
    def __init__(self):
        self.dValueSring = ''
        self.kIsnow = know
        self.dEstDentro = False
        self.dEstDentro_2 = False
        self.dnum2 = 0
        self.dValueSring_2 = ''
        self.dValueSring_3 = ''
        self.dnum3 = 0
        self.dOPXLangNew = LangNew()
        self.dTraducaoPX = ''
        self.dnumImportaDex = 0
        self.dEsNumEs = 0

    def set_tradutor(self, fmsg, ftransletNow = False):
        self.dValueSring = fmsg
        #self.kIsnow.set_giu()
        """
        for niuk in range(len(fmsg)):
            self.dValueSring = fmsg[niuk]
            self.dnum2 = 0
            for opiuk in range(len(self.kIsnow.dDeCadaCaractre)):
                for oioskeins in self.kIsnow.dDeCadaCaractre[opiuk]:
                    for lopStr in oioskeins:
                        self.dValueSring_2 += lopStr[self.dnum3]
                        lopStr += 1
        """

        ###
        if ftransletNow == True:
            """
            #self.dnumImportaDex = self.dOPXLangNew.set_passoTraducao(self.dValueSring)
            self.dOPXLangNew.set_passoTraducao(self.dValueSring, False)
            self.dOPXLangNew.get_obterParaTraduzir()
            self.dnumImportaDex = self.dOPXLangNew.diknum_2 #self.dOPXLangNew.get_obterParaTraduzir()
            if str(self.dnumImportaDex).isnumeric():
                if self.kIsnow.dCaracteresEspeciais[self.dnumImportaDex] == self.dValueSring:
                    self.dValueSring_2 = self.kIsnow.dCaracteresEspeciais[self.dnumImportaDex]
            else:
                self.dValueSring_2 = str(self.dnumImportaDex)
            """
            self.dOPXLangNew.set_passoTraducao(self.dValueSring, False)
            self.dOPXLangNew.get_obterParaTraduzir()
        if (ftransletNow == False):
            #self.dnumImportaDex = self.dOPXLangNew.set_passoTraducao(self.dValueSring, True)
            self.dOPXLangNew.set_passoTraducao(self.dValueSring, True)
            self.dOPXLangNew.get_obterParaTraduzir()
            self.dnumImportaDex = self.dOPXLangNew.diknum_2 #self.dOPXLangNew.get_obterParaTraduzir()
            self.dValueSring = str(self.dOPXLangNew.dklop)

            ###
            """
            if str(self.dnumImportaDex).isnumeric():
                if self.kIsnow.dCaracteresEspeciais[(self.dnumImportaDex)] == self.dValueSring:
                    self.dValueSring_2 = self.kIsnow.dDeCadaCaractre[self.dnumImportaDex]
            else:
                self.dValueSring_2 = str(self.dnumImportaDex)
            """
            ###



    def get_deEscrito(self):
        return self.dOPXLangNew.dDeEscreverValor

    #

    def set_DeleteDeEscrito(self):
        self.dOPXLangNew.set_deleteOwniu()

    def set_deleteOwniu(self):
        self.dOPXLangNew.dklop = []

    def get_translate_(self):
        return self.dOPXLangNew.dklop

    def get_translate_2(self):
        return self.dOPXLangNew.dklop_escrev

    def set_deleteOwniu(self):
        self.dOPXLangNew.dklop_escrev = []

    def set_mudAlls(self, mudarBex):
        self.dOPXLangNew.set_mudarX(mudarBex)

    def set_initAP1(self):
        self.dOPXLangNew.set_confgInit_UIOP1()
