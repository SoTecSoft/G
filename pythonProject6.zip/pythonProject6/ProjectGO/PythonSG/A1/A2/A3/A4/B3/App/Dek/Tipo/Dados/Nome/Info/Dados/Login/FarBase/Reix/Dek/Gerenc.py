#importações

import firebase_admin as dFarBas

class Gernc:
    def __init__(self):
        self.set_init_var()

    #init var
    def set_init_var(self):
        self.dParaEscrever = {}
        self.dOqueFoiLido = ''

        #permissões
        self.dPodeLer = bool
        self.dPodeEscrever = bool
        self.dPodeTudo = bool

    #

    def set_init_class(self):
        self.dFrBase = dFarBas.initialize_app()

    #def set_farBase_escrever(self, dCaminho):
