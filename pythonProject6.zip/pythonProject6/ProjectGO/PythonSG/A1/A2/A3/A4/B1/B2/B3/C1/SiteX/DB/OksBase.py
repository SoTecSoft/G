import IeBase

import sqlite3

c