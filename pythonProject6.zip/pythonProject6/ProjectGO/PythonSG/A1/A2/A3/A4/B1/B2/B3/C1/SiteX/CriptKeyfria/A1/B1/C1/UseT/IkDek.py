import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.CriptKeyfria.Tradetch as dcv_PCT
import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C2.GerationTen.Fiosp as dcv_PGF

class dc_dk:
    def __init__(self):
        self.set_init_Var()
        self.set_init_Classes()

    def set_init_Var(self):
        self.dArgument = ''
        self.dRespot = ''
        self.dLida = ''

        self.dProcess_O1 = ''
        self.dProcess_O2 = ''

        self.dArgumenDeParada = '#breaketing;'
        self.dArgumenDeParada2 = "#end2"
        self.dToCaracteresSuportavelList = []

    def set_escreverChaveEChave(self):
        dCaracteresList = []
        try:
            while self.dArgument != "endIOP":
                print(f"""
                
                DIGITE:"endIOP";
                    oque estar entre aspas em cima para parar 
                OU então:
                    digite outros caracteres para ser os caracteres qe são ser suportados;
                """)
                self.dArgument = input("Escreva Aqui: ")
                if (len(self.dArgument) == 1) or (self.dArgument.count('"') == 2 and (len(self.dArgument.replace('"', '')) >= 1)) or (self.dArgument.count('"') == 2 and self.dArgument.replace('"', '') == "'"):
                    dCaracteresList.append(self.dArgument)
                else:
                    print('OPS! tente novamente')

            dklop = ''
            dklop2 = ''
            dEsCerto = False
            #print('Digite ([end3] or [endIOP]) para parar')
            while self.dArgument != 'end3' or self.dArgument != "endIOP":
                print('Digite um caminho para arquivo para ser lido/criado que leve ao arquivo')
                self.dArgument = input('Digite aqui: ')
                dklop = self.dArgument
                print('Você tem certeza que estar certo? Y para sim e N para não')
                self.dArgument = input('Digite aqui')
                dklop2 = self.dArgument
                if dklop2 == "Y" or dklop2 == 'y':

                    fRepetix = 0
                    fRepetix2 = 0
                    while True:
                        try:
                            self.dArgument = input("Quantas vezes repetir do passo 1: ")
                            fRepetix = int(self.dArgument)
                            self.dArgument = input("Quantas vezes reptir do passo 2: ")
                            fRepetix2 =  int(self.dArgument)
                            self.dPGF.dTantoRepeticao = fRepetix
                            self.dPGF.dTantoRepeticao2 = fRepetix2
                            self.dArgument = input("Estar tudo correto? [Y = para sim]/[N = para não]")
                            if (self.dArgument == 'Y' or self.dArgument == 'y'):
                                break
                        except:
                            print("OPS! SÓ PODE DIGITAR NÚMEROS ATÉ AGORA!")
                        finally:
                            ...

                    #fisktec = self.set_lerArq(dklop, True)
                    self.dPGF.set_argulAll1(dCaracteresList)
                    self.dPGF.set_arguAll2()
                    dArgrutex = ''
                    dArgrutex2 = ''
                    self.dPGF.set_escreverEmArquivo(dklop)
                    """
                    print('digite: "spbreaker"; para parar')
                    while self.dArgument != 'spbreaker':
                        print('Digite caminho de arquivo a onde será escrito')
                        self.dArgument = input('Aqui: ')
                        dArgrutex = self.dArgument
                        print('Estar certo o caminho?')
                        print('DIGITE: Y/y -> PARA SIM; E: N/n -> PARA NÃO;')
                        self.dArgument = input('Digite aqui: ')
                        dArgrutex2 = self.dArgument
                        if dArgrutex2 == 'Y' or dArgrutex2 == 'y':
                            self.dPGF.set_escreverEmArquivo(dArgrutex)
                        if dArgrutex2 == 'n' or dArgrutex2 == 'N':
                            print('repetindo processo...')
                    """
                    break

                else:
                    print('Repetir processo...')
                    continue

        finally:
            ...

    def set_lerDeck(self):
        dArgut = ''
        dArgut2 = ''

        print('Digite: "end1"; para cancelar')
        while self.dArgument != 'end1':
            self.dArgument = input('Digite caminho de arquivo.:')
            dArgut = self.dArgument
            print('Caminho estar certo?')
            print('Y/y para sim ou N/n para não')
            self.dArgument = input('Aqui:')
            dArgut2 = self.dArgument
            if dArgut2 == 'Y' or dArgut2 == 'y':
                self.dProcess_O1 = self.set_lerArq(dArgut)
                print(self.dProcess_O1 + ";")
                self.dPCT.set_deleterX()
                self.dPCT.set_delet_afl_()
                self.dPCT.d_Afl_.set_mudar(self.dProcess_O1)
                self.dPCT.set_Giu()
                break
            else:
                print('Repetindo processo...')

    def set_ParaCriptografarOuDescriptografar(self):
        print('Digite: "end1"; para parar processo...')

        dArgutrex = ''
        dArgutrex2 = ''
        dArgutrex3 = ''
        dArgutrex4 = ''
        dArgutrex5 = ''
        dNumb = 0
        while self.dArgument != 'end1':
            self.dArgument = input('Digite o caminho do arquivo: ')
            dArgutrex = self.dArgument
            self.dArgument = input('Estar certo o caminho do arquivo? Y/y para sim e N/n para não: ')
            dArgutrex2 = self.dArgument
            if dArgutrex2 == 'Y' or dArgutrex2 == 'y':
                #dArgutrex3 = self.set_cofingParaEscreverChaves(dArgutrex)
                dArgutrex4 = self.set_lerArq(dArgutrex)
                self.dPCT.set_mudarTex(dArgutrex4)


                while True:
                    print("""
                
                siga as seguintes instruções:
                    1 -> criptografar;
                    2 -> descriptografarr;
                
                    """)
                    self.dArgument = input('Digite um número aqui: ')
                    dArgutrex5 = self.dArgument
                    try:
                        dNumb = int(dArgutrex5)
                        if dNumb == 1:
                            self.dPCT.set_criptografar()
                            self.dArgument = input('Escreva um caminho para guardar..:')
                            self.set_escreverArq(self.dPCT.get_criptografar(), self.dArgument)
                            break
                        if dNumb == 2:
                            self.dPCT.set_traduzir()
                            self.dArgument = input('Escreva um caminho para guardar..:')
                            self.set_escreverArq(self.dPCT.get_traduzir(), self.dArgument)
                            break
                    except Exception as expt:
                        print(f"mensagem error: {expt}")
                        print('reptindo o processo...')
                        continue


            else:
                print('repetindo processo...')


    def set_init_Classes(self):
        self.dPCT = dcv_PCT.TradutorUE()
        self.dPGF = dcv_PGF.dGerationTec()
        self.dProcess_O2 = self.dPCT.d_Afl_.dOProcesso_1

    def set_lerArq(self, dCaminho, dExtra2 = False, dTipo='utf-8'):
        dIndex2 = 0
        dIndex2_extra2 = 0
        dArgumnt = ''
        dArquiveTec = open(dCaminho, 'r')
        try:
            '''
            for dfiok in dArquiveTec.readlines():
                dIndex2 = dIndex2_extra2
                dIndex2_extra2 += 1
                dArquiveTec += str(dArquiveTec.readlines()[dIndex2])
            '''
            dArgumnt = dArquiveTec.read()
            dArquiveTec.close()
        finally:
            return dArgumnt


    def set_cofingParaEscreverChaves(self, dArgtex):
        dJafoi2 = False
        dJafoi3 = False
        dJafoi4 = False
        dJafoi5 = False

        dRegrasEmList = ['']
        dPared2 = '!'
        dArgtyx = ''

        dArguGeral = ''
        print('Digite:"whlbreaking2"; para parar')
        while self.dArgument != 'whlbreaking2':
            if dJafoi2 == False and dJafoi3 == False and dJafoi4 == False and dJafoi5 == False:

                while dArgtyx != dPared2:
                    print('Deseja trocar substituir qual caractere a outro?:')
                    print('Digte -> Y/y para sim; ou N/n para não;')
                    self.dArgument = input('Digite: ')
                    if len(self.dArgument) > 1:
                        print('OPS! É NECESSÁRIO APENAS 1 CARACTERE E COM A REGRA AO QUA LHE FALEI')
                        continue
                    if len(self.dArgument) <= 0:
                        print("ops! digite algo")
                        continue
                    if len(self.dArgument) == 1:
                        if self.dArgument == 'Y' or self.dArgument == 'y':
                            dklio = ''
                            dklio2 = ''
                            while True:
                                print('Por qual caractere deseja subtstuir?')
                                dklio = input('Digite aqui o caractere inicial: ')
                                self.dArgument = dklio
                                dklio2 = input('O próximo: ')
                                self.dArgument = dklio2
                                if len(dklio) <= 0:
                                    print('ops! digite pelo menos algum caractere, repita o processo')
                                    continue
                                else:
                                    dArguGeral = dArgtex.replace(dklio, dklio2)
                                    dRegrasEmList[0] = dArguGeral
                                    dJafoi2 = True
                                    dArgtex = '!'
                                    break
                        else:
                            dJafoi2 = True
                            break

        return dRegrasEmList


    def set_escreverArq(self,dParaEscrever, dCaminho, dExtra2 = False, dTipo='utf-8'):
        dEscrevert = open(dCaminho, 'w')
        dEscrevert.write(dParaEscrever)

        dEscrevert.close()

    def set_init_gamex(self):
        dNumb = 0

        while self.dArgument != self.dArgumenDeParada:
            print("""
        
        DIGITE:
            1 -> fazer mini limpeza em caso de erro;
            2 -> fazer configuração dos caracteres e chaves;
            3 -> criptografar ou descriptografar;
            4 -> limpeza profunda;
            5 -> criar chaves;
            6 -> ver caracteres suportados;
            """)
            try:
                self.dArgument = input('Digite aqui: ')
                dNumb = int(self.dArgument)
                if dNumb == 1:
                    self.dPCT.set_deleterX()
                    self.dPCT.set_delet_afl_()
                    self.dPCT.d_Afl_.set_mudar(self.dProcess_O1)
                    self.dPCT.set_Giu()
                if dNumb == 2:
                     self.set_lerDeck()
                if dNumb == 5:
                    self.set_escreverChaveEChave()
                if dNumb == 3:
                    self.set_ParaCriptografarOuDescriptografar()
                if dNumb == 4:
                    self.dPCT.set_deleterX()
                    self.dPCT.set_delet_afl_()
                    self.dPCT.d_Afl_.set_mudar(self.dProcess_O2)
                    self.dPCT.set_Giu()

                    self.dPGF.set_deletrex()

                if dNumb == 6:
                    print(f'''
                    CARACTERES SUPORTADOS SÃO ESSES:
                        {self.dPCT.d_Afl_.get_alls_wix(1)}
                    e estes são os caracteres suportados...
                    ''')
            except Exception as extp:
                print('repetindo o processo...')
                print(f"Mensagem:{extp}")
