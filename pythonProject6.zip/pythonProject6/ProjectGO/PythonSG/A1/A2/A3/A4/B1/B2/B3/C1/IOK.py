import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.CriptKeyfria.Ropnan as ropx

dG = ropx.Ink_UopNew()

#

dkou = ("""

{
/q = 1083832092;
/w = nnvfnvonefo;
/e = 029383802029282983476738;
/r = 7750704747407;
/t = 00109390209393920;
/y = 8900594-0409403-3094890303939;
/u = 8585858580984940494840003;
/i = 00000000000001111111111111111188888888888888;
/o = 588595894949849403;
/p = 8940948490039383930;
/a = 4990309800384039303093930;
/s = 84940093893039929389099;
/d = 8599e477407457478457894;
/f = 879o9849394849309383;
/g = 002990393830303939;
/h = 889984949484884;
/j = 99494049940494949;
/l = 859588nnnvrnvev38844h3848g4vg4v8;
/k = 8904347767987689;
/z = 8y8ny348y8yny4v37b87t4tb67cv5rx3ecvb77vz2c2cG;
/x = fqwwuye8gygcbbgwegefbegyf8geeiwbwfevyufef7dffydeutfetfew78y9722578557765727bybc786vc44rvc45;
/c = gveivgvgyvegyveygeyugyfe76f6ff31yg1g18t67r71gyvu6733ey3g67f4;
/v = yxnuxy7xnx89xy7xnxytetx7txn7xb67b7;
/b = y4y84384yn7489xyn47ny4n4ytxy8nxt4xt7x4yn87tbx474xyn74tbx;
/n = y48y489y48y894uy47yn894xyn874yny4nt7yn348x4tx78yx4n3x;
/m = um8mu89umc3ruc39umr8c9rc98;
}

""")
#
dG.set_mudAlls(dkou)
dG.set_initAP1()
dG.set_tradutor("q", False)
print(dG.get_deEscrito())
print(dG.get_translate_())
print(dG.get_translate_2())
