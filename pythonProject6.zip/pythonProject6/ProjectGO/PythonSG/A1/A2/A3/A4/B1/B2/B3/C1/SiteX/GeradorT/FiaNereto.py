import random as rdm
import time

import  ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.CriptKeyfria.AFL as gfl

class Gerator:
    def __init__(self):
        self.dCaracter_ABC = 'qwertyuiopasdfghjklzxcvbnm'
        self.dCaracter_Especiais_2 = ':[}@?_"\'!^~'
        self.dRecebtion = ''
        self.dEscolha2 = 0
        self.dEscolha3 = 0
        self.dRecebtion_2 = ''
        self.dLeitura = ''
        self.dEscrever = ''
        self.dCaminhoDeArquivo = ''
        self.argumGeral_2 = ''
        self.dCont = 0
        self.dArgument = []
        self.dGfl = gfl.TiouKey()
        self.dCont_2 = 0
        self.dCaminhoDeArquivo_2 = r'C:/Users/yytol/PycharmProjects/pythonProject6'
        self.dTerminouBool = False
        self.argumGeral_3_extra2 = ''
        self.dOPX = ''
        self.dCoutY = 0
        self.dCouYXX = 0

    def set_caminhoArquivo(self, caminhoDeArquivo):
        self.dCaminhoDeArquivo = self.dCaminhoDeArquivo_2+caminhoDeArquivo

    def set_escrever(self, oQueEscrever):
        self.dEscrever = oQueEscrever
        with open(self.dCaminhoDeArquivo, 'w') as arquivo:
            arquivo.write(self.dEscrever)

    def set_leitura(self):
        with open(self.dCaminhoDeArquivo,'r') as arquivo:
            self.dLeitura = arquivo.read()


    def set_gerar(self, r_tempoContagem, argumentGeral):
        self.dCont = 0
        #self.argumGeral_2 = str(argumentGeral)
        while True:
            self.dRecebtion_2 = self.dRecebtion
            #self.set_caminhoArquivo('DTSO.txt')
            #self.set_leitura()
            if (('F' or 'f') or ('False' or 'false')) in self.dLeitura:
                break
            else:
                if self.dCont == 5*10:
                    break
            self.dCont += 1
            time.sleep(r_tempoContagem)
            self.set_caminhoArquivo('Nu.txt')
            #self.dRecebtion_2 = self.dRecebtion
            #self.set_escrever(self.dRecebtion_2)
            self.dEscolha2 = rdm.randint(1, 3)
            if self.dEscolha2 == 1:
                self.dRecebtion += self.dCaracter_ABC[rdm.randint(0, len(self.dCaracter_ABC)-1)]
                #self.dRecebtion_2 = self.dRecebtion
            if self.dRecebtion_2 == 2:
                self.dRecebtion += self.dCaracter_Especiais_2[rdm.randint(0, len(self.dCaracter_Especiais_2))]
                #self.dRecebtion_2 = self.dRecebtion
            if self.dEscolha2 == 3:
                self.dRecebtion += str(rdm.randint(0, 9))
                #self.dRecebtion_2 = self.dRecebtion

        self.dRecebtion = ''


    def set_extra2(self, oTempo, oArgument):
        self.argumGeral_2 = oArgument
        #self.dGfl.set_mudar(self.argumGeral_2)
        #self.dCont_2 += 1 ###
        #if self.dCont_2 == 1:
        #self.dGfl.set_mudar(self.argumGeral_2)
        #self.dGfl.set_giu()
        self.argumGeral_2 = self.argumGeral_2.replace('=', ' ')
        self.argumGeral_2 = self.argumGeral_2.replace('0', ' ')
        for dgjk in self.dGfl.dCaracteresEspeciais:
            self.set_gerar(oTempo, oArgument)
            self.argumGeral_2 = self.argumGeral_2.replace(dgjk,f'{dgjk} = {self.dRecebtion_2}')
            for dOPTYX in self.argumGeral_2:
                if ';' in dOPTYX:
                    self.argumGeral_3_extra2 += ';\n'
                    self.dCoutY += 0
                    self.dCouYXX = 1
                    if self.dCoutY == oArgument.count(';'):
                        break
                if '/' in dOPTYX:
                    self.dCouYXX = 2
                else:
                    if self.dCouYXX == 1:
                        if '=' in dOPTYX:
                            self.dCouYXX = 2
                    if self.dCouYXX == 2:
                        self.argumGeral_3_extra2 += dOPTYX



        self.set_escrever(self.argumGeral_3_extra2)
        self.dTerminouBool  = True

    def set_generation(self, rTempo, argumentosT):
        self.dGfl.set_mudar(argumentosT)
        self.dGfl.set_giu()
        cott = 0
        while True:

            if self.dTerminouBool:
                break
            else:
                self.set_extra2(rTempo, argumentosT)

