assR = """


"""