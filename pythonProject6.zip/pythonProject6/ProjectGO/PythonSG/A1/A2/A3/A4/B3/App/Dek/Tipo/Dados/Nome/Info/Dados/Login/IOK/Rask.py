

class dc_Ser_A6:
    def __init__(self):
        self.set_init_var()
        self.set_init_dictPrincipal()

    def set_init_var(self):
        self.dNome = []
        self.dSobNome = []
        self.dIdade = []
        self.dChavePrincipal = []
        self.dNumID = 0
        self.dEsVivo = []
        self.dNumIDs = []
        self.dNicknome = []
        self.dHistoric = []
        self.dTipoSer = []
        self.dLocal = []
        self.dInfoNascimento = []

    def set_init_dictPrincipal(self):
        self.dDictPrincipal = {
            'dNome':self.dNome,
            'dSobNome':self.dNome,
            'dIdade':self.dIdade,
            'dChavePrincipal':self.dChavePrincipal,
            'dNumID':self.dNumID,
            'dEsVivo':self.dEsVivo,
            'dNumIDs':self.dNumIDs,
            'dNickNome':self.dNicknome,
            'dHistoric':self.dHistoric,
            'dTipoSer':self.dTipoSer,
            'dLocalSer':self.dLocal,
            'dInfoNasc':self.dInfoNascimento,
        }


class dc_SerClient_A6:
    def __init__(self):
        self.set_init_var()

    def set_init_var(self):
        self.dSer_A6 = dc_Ser_A6()

        self.dTokenMail = []
        self.dTokenSenha = []
        self.dTokenSenhaSenc = []
        self.dEsAtiva = []
        self.dHistoric = []

    def set_dictPrincipal(self):
        self.dDictPrincipal = {
            'dSer_A6':self.dSer_A6.dDictPrincipal,
            'dTokenMail':self.dTokenMail,
            'dTokenSenha':self.dTokenSenha,
            'dTokenSenhaSenc':self.dTokenSenhaSenc,
            'dEsAtivo':self.dEsAtiva,
            'dHistoric':self.dHistoric,
        }