import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.CriptKeyfria.Tradetch as dEIOX

dProx = dEIOX.TradutorUE()

# mudador


dfr = str('a')

dProx.set_Giu()

dProx.set_mudarTex(dfr)

#inicializador

##dProx.set_Giu()

# traduzir

dProx.set_criptografar()

raxt = dProx.get_criptografar()

print(raxt)


#print(dProx.d_Afl_.get_alls_wix(5))