import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.CriptKeyfria.Tradetch as dEIOX

dProx = dEIOX.TradutorUE()

# mudador


dfr = str('ola tec man')

dProx.set_Giu() # init

dProx.set_mudarTex(dfr) # mudar var geral

#inicializador

##dProx.set_Giu()

# traduzir

dProx.set_criptografar() # criptografar

raxt = dProx.get_criptografar() #obter criptografia

print(f'''
    para ser traduzido:
            {raxt}''')


#print(dProx.d_Afl_.get_alls_wix(5))

#fim

dProx.set_deleterX() # reiniciar 1
dProx.set_init_vars() # reiciniar 2

dfrtrec = raxt #era outro

print('#'*10)
dProx.set_mudarTex(dfrtrec) # parte criptografada para ser descriptograda

#inicializador

##dProx.set_Giu() # não precisa novamente

# traduzir

dProx.set_traduzir() # traduzir parte criptografada

raxtk = dProx.get_traduzir() # obter mensagem descriptografada

print(f'''

parte traduzida:
    {raxtk}''')


#print(dProx.d_Afl_.get_alls_wix(5))