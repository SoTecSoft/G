import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.CriptKeyfria.Tradetch as dTrackshen
import string
import random as dRdient


class dGerationTec:
    def __init__(self):
        self.set_init_vars()
        self.set_init_class()

        self.set_dreiok()

    def set_init_vars(self):
        self.dArgument2 = ''
        self.dArgument2_extra2 = ''
        self.dEscolha = ''
        self.dCoding = ''
        self.dCoding_extra2 = ''

        self.dIndex2 = 0
        self.dIndex2_extra2 = 0
        self.dIndex2_extra3 = 0
        self.dIndex2_extra4 = 0

        self.dTantoRepeticao = 0
        self.dTantoRepeticao_extra2 = 0

        self.dListArgux = []
        self.dListArgux_extra2 = []

        self.dJafoiBoolTrec2 = False

        self.dContexIndex2 = 0
        self.dContexIndex2_extaa2 = 0

        self.dContraxDeck = 0
        self.dContraxDeck_extra2 = 0

        self.dTantoRepeticao2 = 0
        self.dTantoRepeticao2_extra2 = 0

    def set_init_class(self):
        self.dClst = dTrackshen.TradutorUE()

    def set_dreiok(self):
        self.dArgrex = ['=', ';', ',']

    def set_argulAll1(self, gesk):
        fIndex2 = 0
        fIndex2_extra2 = 0

        for drex in gesk:
            fIndex2 = fIndex2_extra2
            fIndex2_extra2 += 1
            self.dListArgux.append(gesk[fIndex2])

    # criar argumento e caractere
    def set_arguAll2(self):
        dUtelDeck2 = 0
        dUtelDeck2_extra2 = 0
        self.dArgument2 = ''

        dJafoiTrick = False

        for driox in self.dListArgux:
            self.dContexIndex2 = self.dContexIndex2_extaa2
            self.dContexIndex2_extaa2 += 1

            if dJafoiTrick == True:
                self.dListArgux_extra2.append('/' + self.dListArgux[self.dContexIndex2] + ' = ' + self.dArgument2.replace('""', '"')) #amtes não tinha replace
            #limpeza
            self.dArgument2 = ''
            for dglock in range(self.dTantoRepeticao2):
                self.dArgument2 += '"'
                for idrex in range(self.dTantoRepeticao):
                    try:
                        dUtelDeck2 = dRdient.randint(0, 2)
                        if dUtelDeck2 == 0:
                            self.dArgument2 += string.ascii_letters[dRdient.randint(0, len(string.ascii_letters)-1)]
                        if dUtelDeck2 == 1:
                            self.dArgument2 += str(dRdient.randint(0, 9))
                        if dUtelDeck2 == 2:
                            self.dArgument2 += self.dArgrex[dRdient.randint(0, len(self.dArgrex)-1)]
                    finally:
                        ...
                ''''
            if idrex == self.dTantoRepeticao:
                for dfriox in range(50):
                    dUtelDeck2 = dRdient.randint(0, 2)
                    if dUtelDeck2 == 0:
                        self.dArgument2 += string.ascii_letters[dRdient.randint(0, len(string.ascii_letters))]
                    if dUtelDeck2 == 1:
                        self.dArgument2 += str(dRdient.randint(0, 9))
                    if dUtelDeck2 == 2:
                        self.dArgument2 += self.dArgrex[dRdient.randint(0, len(self.dArgrex))]
                '''
                self.dArgument2 += '"'
                self.dArgument2 += ','
                self.dArgument2 += '"'
            for idrex in range(self.dTantoRepeticao):
                try:
                    dUtelDeck2 = dRdient.randint(0, 2)
                    if dUtelDeck2 == 0:
                        self.dArgument2 += string.ascii_letters[dRdient.randint(0, len(string.ascii_letters)-1)]
                    if dUtelDeck2 == 1:
                        self.dArgument2 += str(dRdient.randint(0, 9))
                    if dUtelDeck2 == 2:
                        self.dArgument2 += self.dArgrex[dRdient.randint(0, len(self.dArgrex)-1)]
                finally:
                    ...

            self.dArgument2 += '"'

            self.dArgument2 += ';'
            #self.dListArgux_extra2.append('/' + self.dListArgux[self.dContexIndex2] + ' = ' +self.dArgument2)

            '''
            else:
                self.dArgument2 += ','
            '''
            dJafoiTrick = True




    def get_listDek2(self):
        return self.dListArgux_extra2


    def set_escreverEmArquivo(self, dArquivoCaminho):
        fCont = 0
        fCont_extra2 = 0

        with open(dArquivoCaminho, 'w') as dArquivoDrek:
            for frix in self.dListArgux_extra2:
                fCont = fCont_extra2
                fCont_extra2 += 1
                dArquivoDrek.write('\n' + self.dListArgux_extra2[fCont])



dfrinx = dGerationTec()

dfrinx.set_argulAll1('odep')
dfrinx.dTantoRepeticao = 2
dfrinx.dTantoRepeticao2 = 2
dfrinx.set_arguAll2()
print(dfrinx.get_listDek2())

print(string.ascii_letters)