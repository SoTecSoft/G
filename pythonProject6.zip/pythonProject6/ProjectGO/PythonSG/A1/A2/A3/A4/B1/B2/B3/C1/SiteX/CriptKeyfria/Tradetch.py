# só precisa mexer aqui, neste arquvio

import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.CriptKeyfria.AFL as dAfl_

import random as rdtE

class dNewListORK:
    def __init__(self):
        self.set_init_vars()
        self.set_deletrex()

    def set_init_vars(self):
        self.dEscopoInit = False
        self.dEscopoEnd = False
        self.dIOEnd = False
        self.dArguworld = ''
        self.dList = []
        self.dIndex2 = 0
        self.dIndex3 = 0
        self.dArguworld2 = ''
        self.dErtPX = []

        self.dIndexOP2 = 0
        self.dIndexOP3 = 0

        #
        self.dIndexFGx = 0
        self.dIndexFGx2 = 0

    def set_mudarTex(self, vArgument):
        self.dArguworld = vArgument

    def set_ler(self):
        for dts in self.dArguworld:
            self.dIndex2 = self.dIndex3
            self.dIndex3 += 1

            if self.dEscopoInit == False and self.dEscopoEnd == False:
                if self.dArguworld[self.dIndex2] == '[':
                    self.dEscopoInit = True

            if self.dEscopoInit == True and self.dEscopoEnd == False:
                if self.dArguworld[self.dIndex2] != "," and self.dArguworld[self.dIndex2] != "]":
                    self.dArguworld2 += self.dArguworld[self.dIndex2]
                else:

                    if self.dArguworld[self.dIndex2] == ",":
                        self.dList.append(self.dArguworld2.replace('[', ''))
                        self.dArguworld2 = ''
                        self.dIndexOP2 = self.dIndexOP3
                        self.dIndexOP3 += 1

                    if self.dArguworld[self.dIndex2] == "]":
                        self.dList.append(self.dArguworld2.replace(('['), ''))
                        self.dEscopoInit = False


    def get_ler(self):
        return self.dList

    def set_deletrex(self):
        self.set_init_vars()



class TradutorUE:
    def __init__(self):
        self.set_init_vars()
        self.set_deleterX()

        self.d_Afl_ = dAfl_.TiouKey()
        self.dIOPx = dNewListORK()

        self.d_Afl_2 = dAfl_.TiouKey()


    def set_init_vars(self): # # a função mais importante do programa. quando querer usar novamento duas vezes a parte das funçãos, use antes esta parte para apagar os valores da var, e depois use tudo novamente.

        self.dMudarIOX = ''
        self.dPalavras = ''
        self.dPalaworgs = [[] # index [0]
            , [] # palavra chr [1]
            , [] # palavra chr reserva [2]
            , [] # palavra chr teste [3]
            , [], # palvra chr reserva [4]
            [], # index qual escolher [5]
            ]

        self.dArgumenTix2 = ''

        self.dIndex2 = 0
        self.dIndex3 = 0

        self.dLisERK = []

        self.drtEPRSG = ''

        self.dIndexOP2 = 0
        self.dIndexOP3 = 0

    def set_Giu(self): # use este primeiro
        self.d_Afl_.set_giu()

    def set_mudarTex(self, vMudart): # (use este segudamente) umas das partes importantes. mude o valor e vc poderá traduzir as chaves e criptografar as palavras
        self.dMudarIOX = str(vMudart)

        #self.d_Afl_.set_mudar(self.dMudarIOX)

    def get_contListTek(self, dfroex): # não é importante este
        dvarTec = 0
        dvarTec2 = 0
        dvarTec3 = 0
        try:
            for dts in dfroex:
                dvarTec = dvarTec2
                dvarTec2 += 1
        finally:
            return dvarTec

    # leitura
    def set_criptografar(self): # para criptografar, use para criptografar oque foi passado ao 'set_mudarTex'
        for dtx in self.dMudarIOX:
            self.dIndexFREX = self.dIndexFREX2
            self.dIndexFREX2 += 1
            self.dIndex3 = 0
            for dfix in self.d_Afl_.get_alls_wix(1):
                self.dIndex2 = self.dIndex3
                self.dIndex3 += 1
                if self.dMudarIOX[self.dIndexFREX] == self.d_Afl_.get_alls_wix(1)[self.dIndex2]:
                    #self.dArgumenTix2 += str(list(self.d_Afl_.get_alls_wix(5)[self.dIndex2][rdtE.randint(0, len(list(self.d_Afl_.get_alls_wix(5)[self.dIndex2])))]))

                    """
                    self.drtEPRSG = '[' + str(self.d_Afl_.get_alls_wix(5)[self.dIndex2]) + ']'

                    self.dIOPx.set_mudarTex(self.drtEPRSG)

                    self.dIOPx.set_ler()

                    self.dErtPX = self.dIOPx.get_ler()

                    self.dArgumenTix2 += self.dErtPX[rdtE.randint(self.dIndex2, (self.dIndex2+self.dIOPx.dIndexOP2))]

                    self.dIOPx.set_deletrex()

                    self.dIndex3 = 0
                    
                    """
                    '''

                    self.d_Afl_2.dOProcesso_1 = '/' + self.d_Afl_.get_alls_wix(2)[self.dIndex2]

                    self.d_Afl_2.set_giu()

                    if dtx in bool(self.d_Afl_2.get_alls_wix(4)):
                        dIxTec = []
                        dIxStrDec = ''

                        try:
                            for dtsr in self.d_Afl_2.get_alls_wix(2)[self.dIndex2]:
                                if dIxStrDec == ',' or dIxStrDec == ';':
                                    dIxTec.append(dIxStrDec)
                                    dIxStrDec = ''
                                else:
                                    dIxStrDec += dtsr
                        finally:

                            self.dArgumenTix2 += dIxTec[rdtE.randint(0, len(dIxTec))]
                    '''
                    self.dArgumenTix2 = self.d_Afl_.get_alls_wix(5)[self.dIndex2][rdtE.randint(0,(self.get_contListTek(self.d_Afl_.get_alls_wix(5)[self.dIndex2])))]
                    self.dListPalavrasDEK.append(self.dArgumenTix2)

                    #self.dIndex3 = 0
                    break
                else:
                    self.dStrExtraDEK2 += self.dMudarIOX[self.dIndexFREX]

                    if self.dMudarIOX[self.dIndexFREX] in " ":
                        self.dArgumenTix2 = ";"
                        self.dListPalavrasDEK.append(self.dArgumenTix2)
                        self.dStrExtraDEK2 = ''

                        #self.dIndex3 = 0
                        break
    def get_criptografar(self): # para obter criptografia doque foi criptografado
        dioxp = ''
        dcontexT = 0
        dcontex2 = 0
        try:
            for drsx in self.dListPalavrasDEK:
                dcontexT = dcontex2
                dcontex2 += 1

                dioxp += self.dListPalavrasDEK[dcontexT]

        finally:
            return dioxp

    #
    def set_traduzir(self): # para traduzir chaves doque foi passado no set_mudarTex


        #for dtx in self.dMudarIOX:
            '''
            for dfix in self.d_Afl_.get_alls_wix(4):
                self.dIndex2 = self.dIndex3
                self.dIndex3 += 1
                if dtx == bool(dfix[self.dIndex2]):
                    self.dArgumenTix2 += str(self.d_Afl_.get_alls_wix(1)[self.dIndex2])

                    self.dIndex3 = 0

                else:
                    self.dIndex3 = 0
                    if dtx == " ":
                        self.dArgumenTix2 += " "
            '''

            for dtex in self.dMudarIOX:
                self.dIndexFREX = self.dIndexFREX2
                self.dIndexFREX2 += 1
                self.dArgumenEKS2 += self.dMudarIOX[self.dIndexFREX]

                self.dIndex3 = 0

                for dprox in self.d_Afl_.get_alls_wix(5):
                    self.dIndex2 = self.dIndex3
                    self.dIndex3 += 1

                    self.dIndexKEK2 = 0
                    for drext in self.d_Afl_.get_alls_wix(5)[self.dIndex2]:
                            self.dIndexKEK = self.dIndexKEK2
                            self.dIndexKEK2 += 1


                        #if '+' in self.dArgumenEKS2:
                            if self.dArgumenEKS2 == self.d_Afl_.get_alls_wix(5)[self.dIndex2][self.dIndexKEK]:
                                self.dArgumenTix2 =  self.d_Afl_.get_alls_wix(1)[self.dIndex2]
                                self.dListPalavrasDEK2.append(self.dArgumenTix2)
                                self.dArgumenEKS2 = ''


                                #self.dIndexKEK2 = 0
                            else:
                                if self.dArgumenEKS2 == ';':
                                    self.dListPalavrasDEK2.append(' ')

                                    self.dIndexKEK2 = 0
                                    self.dArgumenEKS2 = ''



                                else:
                                    #self.dIndexKEK2 = 0
                                    #self.dArgumenEKS2 = ''
                                    ...







                        #self.dArgumenEKS2 = ''

    def get_traduzir(self): #obter apenas oque foi traduzido
        dioxp = ''
        dcontex = 0
        dcontex2 = 0
        try:
            for drsx in self.dListPalavrasDEK2:
                dcontex = dcontex2
                dcontex2 += 1

                dioxp += self.dListPalavrasDEK2[dcontex]

        finally:
            return dioxp

    def set_deleterX(self): # a função mais importante do programa. quando querer usar novamento duas vezes a parte das funçãos, use antes esta parte para apagar os valores da var, e depois use tudo novamente.
        self.dMudarIOX = ''
        self.dPalavras = ''
        self.dPalaworgs = [[]  # index [0]
            , []  # palavra chr [1]
            , []  # palavra chr reserva [2]
            , []  # palavra chr teste [3]
            , [],  # palvra chr reserva [4]
                           [],  # index qual escolher [5]
                           ]

        self.dArgumenTix2 = ''

        self.dIndex2 = 0
        self.dIndex3 = 0

        self.dLisERK = []

        self.drtEPRSG = ''

        self.dErtPX = []

        #
        self.dIndexFREX = 0
        self.dIndexFREX2 = 0

        self.dArgumenEKS2 = ''
        self.dArgumenEKS2_extra2 = ''

        self.dListPalavrasDEK = []
        self.dListPalavrasDEK2 = []
        self.dListPalavrasDEK3 = []

        self.dStrExtraDEK2 = ''
        self.dStrExtraDEK3 = ''

        self.dIndexKEK = 0
        self.dIndexKEK2 = 0

        self.dIndexTRECTEK2 = 0
        self.dIndexTRECTEK3 = 0

        self.dPalavrTec2 = ''
        self.dPalavrTec3 = ''

        #self.d_Afl_.set_deletrex()

    def set_delet_afl_(self):
        self.d_Afl_.set_deletrex()