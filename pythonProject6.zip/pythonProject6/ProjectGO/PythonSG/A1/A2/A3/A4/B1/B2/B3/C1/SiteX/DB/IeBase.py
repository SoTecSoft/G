# import banco de dados

import sqlite3

class info_Ser_A2:
    def __init__(self):
        self.dNome = ''
        self.dSobNome = ''
        self.dIDNum = ''
        self.dIDChave = ''
        self.dData = ''
        self.dEsVivo = False
        self.dLocal = ''
        self.dSenhaGeral = ''
        self.dRegistro = dict
        self.dTipo = ''

class info_Client_A3:
    def __init__(self):
        self.dSer = info_Ser_A2()
        self.dTokenDeIDG = ''
        self.dSenhaG = ''
        self.dSenhaSec = ''
        self.dEstaAtivo = ''
        self.dtantoDeDinheiro = ''
        self.dMoeda = ''
        self.dTipo = ''