import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.GeradorT.NeretoNite as pgtnn

dGiu = pgtnn.GeretoNiu()

respotaT = ''

dRespotaX2 = ''

#dGiu.set_iniciarAssociacao()

def jiuEks(resposta, tNumX):
    #dGiu.set_iniciarAssociacao()
    dGiu.set_palavras(resposta)
    dGiu.set_iniciarAssociacaoGeral_A2()
    dGiu.set_stgurment(tNumX)
    dRes = dGiu.get_stgurment()
    return dRes

def TTs():
    while True:
        dResT = ''
        respotaT_2 = ''
        respotaT_2Num2 = 0
        respotaT = ''
        if ';' in respotaT:
            break
        else:
            respotaT = input('Digite algo: ')
            respotaT_2 = respotaT
            while True:
                respotaT = input('digite um número')
                respotaT_2Num2 = respotaT
                if respotaT.isnumeric():
                    dResT = jiuEks(respotaT_2, int(respotaT_2Num2))
                    break
                else:
                    if ';' in respotaT:
                        return respotaT
                    else:
                        continue

            print(dResT)
            print('ak')
            dGiu.set_deleteVar_Rpex2()
            return dResT

while True:
    if ';' in dRespotaX2:
        break
    else:
        dRespotaX2 = TTs()