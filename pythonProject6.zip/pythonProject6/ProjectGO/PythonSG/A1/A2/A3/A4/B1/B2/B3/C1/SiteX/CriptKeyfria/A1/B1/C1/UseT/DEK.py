import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.CriptKeyfria.Tradetch as dTradecch


class Prox:

    def __init__(self):
        self.set_init_var()
        self.set_init_Classes()

    def set_init_var(self):
        self.dEscolha = 0
        self.dArgument = ''
        self.dArgumentTREX = ''
        self.dParadaFIN = '@breaker;'

        self.dParteCriptografada = []
        self.dParteDescriptografada = []
        # /, =, ; e nem ",'
        self.dOProcesso_1 = """

                                   {/w = 9891, 911, 119;
                                   /q = @#10010100101, @#9000202990030303031-020022;
                                   /e = 2919, 2999, 2666;
                                   /r = 3593, 3595, 3219;
                                   /t = 4590, 4112;
                                   /y = 5690, 5321;
                                   /u = 6738, 6199, 6781;
                                   /i = 7894, 7993, 7219;
                                   /o = 8901, 8904, 8171;
                                   /p = 918999, 9382789, 84993929;
                                   /a = 3477373, 78837, 477483;
                                   /s = 3838738, 383839, 47883;
                                   /r = 99849030, 849838, 847483;
                                   /d = 8847939383, 8487839383838, 48487833;
                                   /f = 478373783, 8447748474747, 48847474747477;
                                   /g = 11.111, 3899, 489393, 111111111111111;
                                   /h = 8888888, 88181818188181818188, 37737373737;
                                   /j = 10932092920;
                                   /k = 9999911111, 93939393939, 10983999283890;
                                   /l = 388398282, 83999, 3982281;
                                   /z = 1171771717, 8383789287, 1661611516;
                                   /x = 388737287262781, 8388878920999999, 4847478383888373828873883873787637873645362789999999;
                                   /c = 38893938382992229829119119, 4887378288228, 3888283829828282828;
                                   /v = 93889383292828292, 48838992828, 8388388383983828282888282828;
                                   /b = 7376546736363, 77783878383738, 73838383838;
                                   /n = 999.999.999.999.999.999.999.999.999, 994303990209020, 94449949;
                                   /m = 494949994844444444444444444444444444444444444499999999999999999999, 8444444444444444444444444444, 84444448488;
                                   /0 = rc9hr8cnny34gbc37bc4v2365vfrd5d5ed5fb23xbf632fvx5r23f6, rg74gb7x7gnqij9dg7g282u8yy7y7n839333333333333333333333333333333301111111111111111111111111111111111111111111111111111111111111111111111111, jbreibur crh8urh8rc h8yry8ry8bu uxhunuin icr;
                                   /1 = fkkkkkkkkkodkfoeeeeeeeeeeeeeeeeeemccccccccccccccccccccccccc8444444444444444444, wooooooooooooooooooooowwwwwwwwwwwwwwwwwwwwwwaaaaaaaaaaaaaawiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiifnnnnnnnnnnnnnnnnnnnnnnnnnnnnn, sççççççççççççççççççççççççççkffffffffffffffldddddddddddddddddsççççççççççalllllllllllllllllllllrnfvjfbrbrnronnroe;
                                   /( = knvibOPKJIOJJUEHUHWEY473387829OIBDCDY8O1KMN, BFNJKDOIUY4GBRNFMXKISUWY4GVRBDNJSI0APWLKMN4RBFHCUXI, FBNDJSIWUEYRGFBCNJXISUEYRGFBCNXJSHEGRTYDUXK;
                                   /) = GHNCMX,LSEIRHFBNCMXKLDRKTF,DKJRUTRFJDKOKRUTHFJDKOERIUTYHFJDKO;
                                   /- = ROORJNVJFNFNFJHFEBBFUBUBHbBUUYBBVvhuVYbbUVuvBIg7G7Yb8g67F65DrYUHVt6dr5C6Y, 8T7Vuvv7yvvvvbuvyt7bb7fcyvyt5eryvrDRCc6rdrctycrvyvTRCRVYTCRCTYVCrtcrtvy, vtcvc6rtvyctyc6rcycrt;

                                   },
                                   """.strip()

    def set_init_Classes(self):
        self.dPtrix = dTradecch.TradutorUE()

    def drexk(self):
        self.dPtrix.d_Afl_.set_mudar(self.dOProcesso_1)

        self.dPtrix.set_Giu()

        while self.dArgumentTREX != self.dParadaFIN:
            try:
                (print(f"""
                
                digite:
                    1: para mudar a linguagem associada;
                    2: para criptografar e descriptografar;
                    3: para fazer reiniciação leve;
                    4: reinicar caso houva erro
                    5: ver caracteres suportados
                    e -> [{self.dParadaFIN}] para parar
                    
                    
                """))

                self.dArgument = input("digite aqui:")
                self.dArgumentTREX = self.dArgument

                if int(self.dArgument) == 1:
                    self.dPtrix.set_deleterX()
                    self.dPtrix.set_delet_afl_()

                    self.dArgument = input("comece por aqui a mudar a linguagem associada, ex: '/a = 10, 8&;' e etc;")
                    self.dPtrix.d_Afl_.set_mudar(self.dArgument)

                    self.dPtrix.set_Giu()



                    continue
                if int(self.dArgument) == 2:
                    self.dArgument = input('Escreva algo:')

                    self.dPtrix.set_mudarTex(self.dArgument)

                    self.dPtrix.set_criptografar()

                    dfoix = self.dPtrix.get_criptografar()

                    #
                    self.dPtrix.set_deleterX()
                    self.dPtrix.set_delet_afl_()
                    self.dPtrix.d_Afl_.set_mudar(self.dOProcesso_1)
                    self.dPtrix.set_Giu()


                    self.dPtrix.set_mudarTex(dfoix)
                    self.dPtrix.set_traduzir()

                    dfroix2 = self.dPtrix.get_traduzir()

                    print(f"""

                        parte criptograda:
                            {dfoix}
                        parte descriptografada:
                            [{dfroix2}]
                            aparece {len(dfroix2)} caracteres de: {dfroix2}
                        
                    """)

                    #


                    continue
                if int(self.dArgument == 3):
                    self.dPtrix.set_deleterX()
                    self.dPtrix.set_delet_afl_()

                    '''
                    self.dOProcesso_1 = """

                           {/w = 9891, 911, 119;
                           /q = 1891, 1, 11, 1711;
                           /e = 2919, 2999, 2666;
                           /r = 3593, 3595, 3219;
                           /t = 4590, 4112;
                           /y = 5690, 5321;
                           /u = 6738, 6199, 6781;
                           /i = 7894, 7993, 7219;
                           /o = 8901, 8904, 8171;
                           /p = 918999, 9382789, 84993929;
                           /a = 3477373, 78837, 477483;
                           /s = 3838738, 383839, 47883;
                           /r = 99849030, 849838, 847483;
                           /d = 8847939383, 8487839383838, 48487833;
                           /f = 478373783, 8447748474747, 48847474747477;
                           /g = 11.111, 3899, 489393, 111111111111111;
                           /h = 8888888, 88181818188181818188, 37737373737;
                           /j = 10932092920;
                           /k = 9999911111, 93939393939, 10983999283890;
                           /l = 388398282, 83999, 3982281;
                           /z = 1171771717, 8383789287, 1661611516;
                           /x = 388737287262781, 8388878920999999, 4847478383888373828873883873787637873645362789999999;
                           /c = 38893938382992229829119119, 4887378288228, 3888283829828282828;
                           /v = 93889383292828292, 48838992828, 8388388383983828282888282828;
                           /b = 7376546736363, 77783878383738, 73838383838;
                           /n = 999.999.999.999.999.999.999.999.999, 994303990209020, 94449949;
                           /m = 494949994844444444444444444444444444444444444499999999999999999999, 8444444444444444444444444444, 84444448488;
                           /0 = rc9hr8cnny34gbc37bc4v2365vfrd5d5ed5fb23xbf632fvx5r23f6, rg74gb7x7gnqij9dg7g282u8yy7y7n839333333333333333333333333333333301111111111111111111111111111111111111111111111111111111111111111111111111, jbreibur crh8urh8rc h8yry8ry8bu uxhunuin icr;
                           /1 = fkkkkkkkkkodkfoeeeeeeeeeeeeeeeeeemccccccccccccccccccccccccc8444444444444444444, wooooooooooooooooooooowwwwwwwwwwwwwwwwwwwwwwaaaaaaaaaaaaaawiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiifnnnnnnnnnnnnnnnnnnnnnnnnnnnnn, sççççççççççççççççççççççççççkffffffffffffffldddddddddddddddddsççççççççççalllllllllllllllllllllrnfvjfbrbrnronnroe;
                           /( = knvibOPKJIOJJUEHUHWEY473387829OIBDCDY8O1KMN, BFNJKDOIUY4GBRNFMXKISUWY4GVRBDNJSI0APWLKMN4RBFHCUXI, FBNDJSIWUEYRGFBCNJXISUEYRGFBCNXJSHEGRTYDUXK;
                           /) = GHNCMX,LSEIRHFBNCMXKLDRKTF,DKJRUTRFJDKOKRUTHFJDKOERIUTYHFJDKO;
                           /- = ROORJNVJFNFNFJHFEBBFUBUBHbBUUYBBVvhuVYbbUVuvBIg7G7Yb8g67F65DrYUHVt6dr5C6Y, 8T7Vuvv7yvvvvbuvyt7bb7fcyvyt5eryvrDRCc6rdrctycrvyvTRCRVYTCRCTYVCrtcrtvy, vtcvc6rtvyctyc6rcycrt;

                           },
                           """.strip()
                    '''
                    self.dPtrix.d_Afl_.set_mudar(self.dOProcesso_1)
                    self.dPtrix.set_Giu()

                    continue
                if self.dArgument in self.dParadaFIN:
                    break

                if int(self.dArgument) == 4:
                    self.dPtrix.set_deleterX()
                    self.dPtrix.set_delet_afl_()

                    self.dPtrix.d_Afl_.set_mudar(self.dOProcesso_1)
                    self.dPtrix.set_Giu()

                if int(self.dArgument) == 5:
                    for friox in self.dPtrix.d_Afl_.get_alls_wix(1):
                        print(f'{friox}\n')
                    print("terminou,e estes são os caracteres suportados")

            except:
                print("""
                ERROR:
                    quando lhe pedir para digitar números, digite apenas numeros.
                        tente digitar número novamente por favor, escolha um. 
                    e digite apenas caracteres suportados! ou digite 4 caso tenha erro.
                
                """)

            finally:
                ...


# usar código

grox = Prox()

grox.drexk()