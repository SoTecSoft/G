import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.CriptKeyfria.Tradetch as dTradecch

import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C2.GerationTen.Fiosp as dGFiosp

'''
antes:
    6: apenas traduzir
    7: apenas criptografar
    8: para ver as partes criptografada e descriptografada

'''

class Prox:

    def __init__(self):
        self.set_init_var()
        self.set_init_Classes()

    def set_init_var(self):
        self.dEscolha = 0
        self.dArgument = ''
        self.dArgumentTREX = ''
        self.dParadaFIN = '@breaker;'

        #
        self.dListyArgunt = []
        self.dListyArgunt_extra2 = []

        self.dListyArgunt2 = []
        self.dListyArgunt2_extra2 = []

        #
        self.dListyArgunt3 = []
        self.dListyArgunt3_extra2 = []

        self.dParteCriptografada = []
        self.dParteDescriptografada = []
        # /, =, ; e nem ",'
        self.dOProcesso_1 = """

                                   {/w = 9891, 911, 119;
                                   /q = @#10010100101, @#9000202990030303031-020022;
                                   /e = 2919, 2999, 2666;
                                   /r = 3593, 3595, 3219;
                                   /t = 4590, 4112;
                                   /y = 5690, 5321;
                                   /u = 6738, 6199, 6781;
                                   /i = 7894, 7993, 7219;
                                   /o = 8901, 8904, 8171;
                                   /p = 918999, 9382789, 84993929;
                                   /a = 3477373, 78837, 477483;
                                   /s = 3838738, 383839, 47883;
                                   /r = 99849030, 849838, 847483;
                                   /d = 8847939383, 8487839383838, 48487833;
                                   /f = 478373783, 8447748474747, 48847474747477;
                                   /g = 11.111, 3899, 489393, 111111111111111;
                                   /h = 8888888, 88181818188181818188, 37737373737;
                                   /j = 10932092920;
                                   /k = 9999911111, 93939393939, 10983999283890;
                                   /l = 388398282, 83999, 3982281;
                                   /z = 1171771717, 8383789287, 1661611516;
                                   /x = 388737287262781, 8388878920999999, 4847478383888373828873883873787637873645362789999999;
                                   /c = 38893938382992229829119119, 4887378288228, 3888283829828282828;
                                   /v = 93889383292828292, 48838992828, 8388388383983828282888282828;
                                   /b = 7376546736363, 77783878383738, 73838383838;
                                   /n = 999.999.999.999.999.999.999.999.999, 994303990209020, 94449949;
                                   /m = 494949994844444444444444444444444444444444444499999999999999999999, 8444444444444444444444444444, 84444448488;
                                   /0 = rc9hr8cnny34gbc37bc4v2365vfrd5d5ed5fb23xbf632fvx5r23f6, rg74gb7x7gnqij9dg7g282u8yy7y7n839333333333333333333333333333333301111111111111111111111111111111111111111111111111111111111111111111111111, jbreibur crh8urh8rc h8yry8ry8bu uxhunuin icr;
                                   /1 = fkkkkkkkkkodkfoeeeeeeeeeeeeeeeeeemccccccccccccccccccccccccc8444444444444444444, wooooooooooooooooooooowwwwwwwwwwwwwwwwwwwwwwaaaaaaaaaaaaaawiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiifnnnnnnnnnnnnnnnnnnnnnnnnnnnnn, sççççççççççççççççççççççççççkffffffffffffffldddddddddddddddddsççççççççççalllllllllllllllllllllrnfvjfbrbrnronnroe;
                                   /( = knvibOPKJIOJJUEHUHWEY473387829OIBDCDY8O1KMN, BFNJKDOIUY4GBRNFMXKISUWY4GVRBDNJSI0APWLKMN4RBFHCUXI, FBNDJSIWUEYRGFBCNJXISUEYRGFBCNXJSHEGRTYDUXK;
                                   /) = GHNCMX,LSEIRHFBNCMXKLDRKTF,DKJRUTRFJDKOKRUTHFJDKOERIUTYHFJDKO;
                                   /- = ROORJNVJFNFNFJHFEBBFUBUBHbBUUYBBVvhuVYbbUVuvBIg7G7Yb8g67F65DrYUHVt6dr5C6Y, 8T7Vuvv7yvvvvbuvyt7bb7fcyvyt5eryvrDRCc6rdrctycrvyvTRCRVYTCRCTYVCrtcrtvy, vtcvc6rtvyctyc6rcycrt;

                                   },
                                   """.strip()

        self.dOProcesso_Fruxt2 = """

                                           {/w = 9891, 911, 119;
                                           /q = @#10010100101, @#9000202990030303031-020022;
                                           /e = 2919, 2999, 2666;
                                           /r = 3593, 3595, 3219;
                                           /t = 4590, 4112;
                                           /y = 5690, 5321;
                                           /u = 6738, 6199, 6781;
                                           /i = 7894, 7993, 7219;
                                           /o = 8901, 8904, 8171;
                                           /p = 918999, 9382789, 84993929;
                                           /a = 3477373, 78837, 477483;
                                           /s = 3838738, 383839, 47883;
                                           /r = 99849030, 849838, 847483;
                                           /d = 8847939383, 8487839383838, 48487833;
                                           /f = 478373783, 8447748474747, 48847474747477;
                                           /g = 11.111, 3899, 489393, 111111111111111;
                                           /h = 8888888, 88181818188181818188, 37737373737;
                                           /j = 10932092920;
                                           /k = 9999911111, 93939393939, 10983999283890;
                                           /l = 388398282, 83999, 3982281;
                                           /z = 1171771717, 8383789287, 1661611516;
                                           /x = 388737287262781, 8388878920999999, 4847478383888373828873883873787637873645362789999999;
                                           /c = 38893938382992229829119119, 4887378288228, 3888283829828282828;
                                           /v = 93889383292828292, 48838992828, 8388388383983828282888282828;
                                           /b = 7376546736363, 77783878383738, 73838383838;
                                           /n = 999.999.999.999.999.999.999.999.999, 994303990209020, 94449949;
                                           /m = 494949994844444444444444444444444444444444444499999999999999999999, 8444444444444444444444444444, 84444448488;
                                           /0 = rc9hr8cnny34gbc37bc4v2365vfrd5d5ed5fb23xbf632fvx5r23f6, rg74gb7x7gnqij9dg7g282u8yy7y7n839333333333333333333333333333333301111111111111111111111111111111111111111111111111111111111111111111111111, jbreibur crh8urh8rc h8yry8ry8bu uxhunuin icr;
                                           /1 = fkkkkkkkkkodkfoeeeeeeeeeeeeeeeeeemccccccccccccccccccccccccc8444444444444444444, wooooooooooooooooooooowwwwwwwwwwwwwwwwwwwwwwaaaaaaaaaaaaaawiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiifnnnnnnnnnnnnnnnnnnnnnnnnnnnnn, sççççççççççççççççççççççççççkffffffffffffffldddddddddddddddddsççççççççççalllllllllllllllllllllrnfvjfbrbrnronnroe;
                                           /( = knvibOPKJIOJJUEHUHWEY473387829OIBDCDY8O1KMN, BFNJKDOIUY4GBRNFMXKISUWY4GVRBDNJSI0APWLKMN4RBFHCUXI, FBNDJSIWUEYRGFBCNJXISUEYRGFBCNXJSHEGRTYDUXK;
                                           /) = GHNCMX,LSEIRHFBNCMXKLDRKTF,DKJRUTRFJDKOKRUTHFJDKOERIUTYHFJDKO;
                                           /- = ROORJNVJFNFNFJHFEBBFUBUBHbBUUYBBVvhuVYbbUVuvBIg7G7Yb8g67F65DrYUHVt6dr5C6Y, 8T7Vuvv7yvvvvbuvyt7bb7fcyvyt5eryvrDRCc6rdrctycrvyvTRCRVYTCRCTYVCrtcrtvy, vtcvc6rtvyctyc6rcycrt;

                                           },
                                           """.strip()
        self.dConteuDrox = ''

    def set_init_Classes(self):
        self.dPtrix = dTradecch.TradutorUE()
        self.dGFiosprek = dGFiosp.dGerationTec()

    def drexk(self):
        self.dPtrix.d_Afl_.set_mudar(self.dOProcesso_1)

        self.dPtrix.set_Giu()

        while self.dArgumentTREX != self.dParadaFIN:
            try:
                (print(f"""
                
                digite:
                    1: para mudar a linguagem associada;
                    2: para criptografar e descriptografar;
                    3: para fazer reiniciação leve;
                    4: reinicar caso houva erro;
                    5: ver caracteres suportados;
                    10: reinicialização completa;
                    11: ler arquivo;
                    12: para criptografar ou descriptografar;
                    13: para criar chaves aleatórias com os caracteres ao qual vc quer
                    e -> [{self.dParadaFIN}] para parar
                    
                    
                """))

                self.dArgument = input("digite aqui:")
                self.dArgumentTREX = self.dArgument

                if int(self.dArgument) == 1:
                    self.dPtrix.set_deleterX()
                    self.dPtrix.set_delet_afl_()

                    self.dArgument = input("comece por aqui a mudar a linguagem associada, ex: '/a = 10, 8&;' e etc; ->:")

                    self.dOProcesso_1 = self.dArgument.strip()

                    self.dPtrix.d_Afl_.set_mudar(self.dOProcesso_1)

                    self.dPtrix.set_Giu()



                    continue
                if int(self.dArgument) == 2:
                    self.dArgument = input('Escreva algo:')

                    self.dPtrix.set_mudarTex(self.dArgument)

                    self.dPtrix.set_criptografar()

                    dfoix = self.dPtrix.get_criptografar()

                    #
                    self.dPtrix.set_deleterX()
                    self.dPtrix.set_delet_afl_()
                    self.dPtrix.d_Afl_.set_mudar(self.dOProcesso_1)
                    self.dPtrix.set_Giu()


                    self.dPtrix.set_mudarTex(dfoix)
                    self.dPtrix.set_traduzir()

                    dfroix2 = self.dPtrix.get_traduzir()

                    print(f"""

                        parte criptograda:
                            {dfoix}
                        parte descriptografada:
                            [{dfroix2}]
                            aparece {len(dfroix2)} caracteres de: {dfroix2}
                        
                    """)

                    self.dListyArgunt3.append(f'parte criptografada:{dfoix}; parte traduzida:{dfroix2}')

                    #


                    continue
                if int(self.dArgument == 3):
                    self.dPtrix.set_deleterX()
                    self.dPtrix.set_delet_afl_()

                    '''
                    self.dOProcesso_1 = """

                           {/w = 9891, 911, 119;
                           /q = 1891, 1, 11, 1711;
                           /e = 2919, 2999, 2666;
                           /r = 3593, 3595, 3219;
                           /t = 4590, 4112;
                           /y = 5690, 5321;
                           /u = 6738, 6199, 6781;
                           /i = 7894, 7993, 7219;
                           /o = 8901, 8904, 8171;
                           /p = 918999, 9382789, 84993929;
                           /a = 3477373, 78837, 477483;
                           /s = 3838738, 383839, 47883;
                           /r = 99849030, 849838, 847483;
                           /d = 8847939383, 8487839383838, 48487833;
                           /f = 478373783, 8447748474747, 48847474747477;
                           /g = 11.111, 3899, 489393, 111111111111111;
                           /h = 8888888, 88181818188181818188, 37737373737;
                           /j = 10932092920;
                           /k = 9999911111, 93939393939, 10983999283890;
                           /l = 388398282, 83999, 3982281;
                           /z = 1171771717, 8383789287, 1661611516;
                           /x = 388737287262781, 8388878920999999, 4847478383888373828873883873787637873645362789999999;
                           /c = 38893938382992229829119119, 4887378288228, 3888283829828282828;
                           /v = 93889383292828292, 48838992828, 8388388383983828282888282828;
                           /b = 7376546736363, 77783878383738, 73838383838;
                           /n = 999.999.999.999.999.999.999.999.999, 994303990209020, 94449949;
                           /m = 494949994844444444444444444444444444444444444499999999999999999999, 8444444444444444444444444444, 84444448488;
                           /0 = rc9hr8cnny34gbc37bc4v2365vfrd5d5ed5fb23xbf632fvx5r23f6, rg74gb7x7gnqij9dg7g282u8yy7y7n839333333333333333333333333333333301111111111111111111111111111111111111111111111111111111111111111111111111, jbreibur crh8urh8rc h8yry8ry8bu uxhunuin icr;
                           /1 = fkkkkkkkkkodkfoeeeeeeeeeeeeeeeeeemccccccccccccccccccccccccc8444444444444444444, wooooooooooooooooooooowwwwwwwwwwwwwwwwwwwwwwaaaaaaaaaaaaaawiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiifnnnnnnnnnnnnnnnnnnnnnnnnnnnnn, sççççççççççççççççççççççççççkffffffffffffffldddddddddddddddddsççççççççççalllllllllllllllllllllrnfvjfbrbrnronnroe;
                           /( = knvibOPKJIOJJUEHUHWEY473387829OIBDCDY8O1KMN, BFNJKDOIUY4GBRNFMXKISUWY4GVRBDNJSI0APWLKMN4RBFHCUXI, FBNDJSIWUEYRGFBCNJXISUEYRGFBCNXJSHEGRTYDUXK;
                           /) = GHNCMX,LSEIRHFBNCMXKLDRKTF,DKJRUTRFJDKOKRUTHFJDKOERIUTYHFJDKO;
                           /- = ROORJNVJFNFNFJHFEBBFUBUBHbBUUYBBVvhuVYbbUVuvBIg7G7Yb8g67F65DrYUHVt6dr5C6Y, 8T7Vuvv7yvvvvbuvyt7bb7fcyvyt5eryvrDRCc6rdrctycrvyvTRCRVYTCRCTYVCrtcrtvy, vtcvc6rtvyctyc6rcycrt;

                           },
                           """.strip()
                    '''
                    self.dPtrix.d_Afl_.set_mudar(self.dOProcesso_1)
                    self.dPtrix.set_Giu()

                    continue
                if self.dArgument in self.dParadaFIN:
                    break

                if int(self.dArgument) == 4:
                    self.dPtrix.set_deleterX()
                    self.dPtrix.set_delet_afl_()

                    self.dPtrix.d_Afl_.set_mudar(self.dOProcesso_1)
                    self.dPtrix.set_Giu()
                    self.dGFiosprek.set_init_vars()

                if int(self.dArgument) == 5:
                    for friox in self.dPtrix.d_Afl_.get_alls_wix(1):
                        print(f'{friox}\n')
                    print("terminou,e estes são os caracteres suportados")

                if int(self.dArgument) == 6:
                    self.dArgument = input("Escreva algo")
                    self.dPtrix.set_mudarTex(self.dArgument)
                    self.dPtrix.set_traduzir()
                    drox = (f'antes:{self.dArgument}; depois:{self.dPtrix.get_traduzir()}')

                    self.dListyArgunt.append(drox)

                    print(f'parte traduzida: {self.dListyArgunt[0]}')

                if int(self.dArgument) == 7:
                    self.dArgument = input('Digite algo para ser criptografado:')
                    self.dPtrix.set_mudarTex(self.dArgument)
                    self.dPtrix.set_criptografar()
                    drox = (f'antes:{self.dArgument};depois{self.dPtrix.get_criptografar()}')
                    self.dListyArgunt2.append(drox)

                    self.dPtrix.set_deleterX()
                    self.dPtrix.set_delet_afl_()
                    self.dPtrix.d_Afl_.set_mudar(self.dOProcesso_1)
                    self.dPtrix.set_Giu()

                if int(self.dArgument) == 8:
                    print(f'partes criptografadas: {self.dListyArgunt2}')
                    print(f'partes descriptografadas: {self.dListyArgunt}')
                    print(f'os dois juntos: {self.dListyArgunt3}')

                if int(self.dArgument) == 10:
                    self.dPtrix.set_deleterX()
                    self.dPtrix.set_delet_afl_()

                    self.dOProcesso_1 = self.dOProcesso_Fruxt2

                    self.dPtrix.d_Afl_.set_mudar(self.dOProcesso_1)
                    self.dPtrix.set_Giu()

                    self.dGFiosprek.set_init_vars()

                if int(self.dArgument) == 11:


                    try:
                        self.dArgument = input('digite o caminho que leve ao arquivo:')
                        with open(self.dArgument) as arquivetTec:
                            self.dConteuDrox = arquivetTec.read()
                        self.dOProcesso_1 = self.dConteuDrox
                        self.dPtrix.d_Afl_.set_mudar(self.dOProcesso_1)
                        print('digite 4 agora')
                    except FileNotFoundError:
                        print('arquivo não encotrado...')
                    except IOError:
                        print('Ocorreu um erro ao ler o arquivo...')

                if int(self.dArgument) == 12:
                    dMsgProxDek = ''
                    dCorret = False

                    try:
                        print("Digite uma pasta com arquivo, um caminho completo que leve ao arquivo para ser criptografado ou descriptografado")
                        self.dArgument = input('digite aqui:')

                        with open(self.dArgument) as arquivetTec:
                            self.dConteuDrox = arquivetTec.read()
                        dMsgProxDek = self.dConteuDrox
                        print('''
                        agora:
                            1 -> criptografar;
                            2 -> descriptografar;
                        ''')
                        self.dArgument = input('digite aqui:')
                        while dCorret != True:
                            try:
                                self.dPtrix.set_mudarTex(str(dMsgProxDek))

                                if 'endbreaker' in self.dArgument:
                                    break
                                if int(self.dArgument) == 1:
                                    self.dPtrix.set_criptografar()
                                    print(f'parte criptografada:\n\t{self.dPtrix.get_criptografar()}')
                                    dCorret = True
                                if int(self.dArgument) == 2:
                                    self.dPtrix.set_traduzir()
                                    print(f'parte descriptografada:\n\t{self.dPtrix.get_traduzir()}')
                                    dCorret = True
                            except:
                                print("""
                                
                                OPS:
                                    SÓ PODE SER ACEITO NÚMEROS QUANDO LHE PEDIR NÚMEROS e quando lhe pedir alguma outra coisa, digite certo;
                                
                                """)
                                break
                            finally:
                                self.dPtrix.set_deleterX()
                                self.dPtrix.set_delet_afl_()
                                self.dPtrix.d_Afl_.set_mudar(self.dOProcesso_1)
                                self.dPtrix.set_Giu()
                                break



                        print('digite 4 agora')
                    finally:
                        pass


                if int(self.dArgument) == 13:
                    dRualky = []
                    dRualkyTrex = []

                    fIndex2 = 0
                    fIndex2_extra2 = 0

                    fIndex3 = 0
                    fIndex3_extra2 = 0

                    dnumberExtra_extra2 = 0

                    dnumberExtra = int(input('o tamanho de cada caractere para cada chave diferente (só vale números int):'))
                    #dnumberExtra_extra2 = int(input('o tamanho de caracteres conjuntos '))
                    dnumberExtra_extra2 = int(input('o tanto de chaves (só vale números int):'))

                    self.dGFiosprek.dTantoRepeticao = dnumberExtra
                    self.dGFiosprek.dTantoRepeticao2 = dnumberExtra_extra2

                    print('digite: [#breaketing] para terminar o processo')
                    while self.dArgument != '#breaketing;':
                        if self.dArgument == '#breaketing':
                            break
                        else:
                            fIndex3 = fIndex3_extra2
                            fIndex3_extra2 += 1
                            self.dArgument = str(input(f'Escreva o {fIndex3+1}° caractére: '))
                            if len(self.dArgument) <= 0:
                                print('vc precisa digitar algo, algum caractere')
                            else:
                                dfriotreck = 0
                                dfriotreck_extra2 = 0
                                dJaExisteTreix = False
                                dCaracteresJaColocados = ''
                                if len(dRualky) >= 1:
                                    for dioprex in dRualky:
                                        dfriotreck = dfriotreck_extra2
                                        dfriotreck_extra2 += 1
                                        if self.dArgument == dRualky[dfriotreck]:
                                            dJaExisteTreix = True
                                            print(f'OPS! VOCÊ JÁ COLOCOU O CARACTERE:{self.dArgument}; caracteres não podem se repetir, coloque outro.')
                                            break
                                        else:
                                            dJaExisteTreix = False

                                    if dJaExisteTreix == False:
                                        dRualky.append(self.dArgument)
                                    if dJaExisteTreix == True:
                                        continue
                                else:
                                    dRualky.append(self.dArgument)

                    #for druealky in dRualky:
                        #fIndex2 = fIndex2_extra2
                        #fIndex2_extra2 += 1
                    self.dGFiosprek.set_argulAll1(dRualky)
                    self.dGFiosprek.set_arguAll2()

                    dCaminhoArquivo = str(input('Digite caminho para arquivo:'))
                    self.dGFiosprek.set_escreverEmArquivo(dCaminhoArquivo)

                    print(self.dGFiosprek.get_listDek2())

                    self.dGFiosprek.set_init_vars()




            except:
                print("""
                ERROR:
                    quando lhe pedir para digitar números, digite apenas numeros.
                        tente digitar número novamente por favor, escolha um. 
                    e digite apenas caracteres suportados! ou digite 4 caso tenha erro.
                
                """)

            finally:
                print('Digite 4 agora e depois escolha oque quer novamente')
                print('Repita este processo')




# usar código

grox = Prox()

grox.drexk()