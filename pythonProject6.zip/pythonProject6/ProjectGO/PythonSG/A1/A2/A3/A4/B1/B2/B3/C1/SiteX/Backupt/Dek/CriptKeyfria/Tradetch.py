# só precisa mexer aqui, neste arquvio

import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.CriptKeyfria.AFL as dAfl_

import random as rdtE

class dNewListORK:
    def __init__(self):
        self.set_init_vars()

    def set_init_vars(self):
        self.dEscopoInit = False
        self.dEscopoEnd = False
        self.dIOEnd = False
        self.dArguworld = ''
        self.dList = []
        self.dIndex2 = 0
        self.dIndex3 = 0
        self.dArguworld2 = ''
        self.dErtPX = []

        self.dIndexOP2 = 0
        self.dIndexOP3 = 0

        #
        self.dIndexFGx = 0
        self.dIndexFGx2 = 0

    def set_mudarTex(self, vArgument):
        self.dArguworld = vArgument

    def set_ler(self):
        for dts in self.dArguworld:
            self.dIndex2 = self.dIndex3
            self.dIndex3 += 1

            if self.dEscopoInit == False and self.dEscopoEnd == False:
                if self.dArguworld[self.dIndex2] == '[':
                    self.dEscopoInit = True

            if self.dEscopoInit == True and self.dEscopoEnd == False:
                if self.dArguworld[self.dIndex2] != "," and self.dArguworld[self.dIndex2] != "]":
                    self.dArguworld2 += self.dArguworld[self.dIndex2]
                else:

                    if self.dArguworld[self.dIndex2] == ",":
                        self.dList.append(self.dArguworld2.replace('[', ''))
                        self.dArguworld2 = ''
                        self.dIndexOP2 = self.dIndexOP3
                        self.dIndexOP3 += 1

                    if self.dArguworld[self.dIndex2] == "]":
                        self.dList.append(self.dArguworld2.replace(('['), ''))
                        self.dEscopoInit = False


    def get_ler(self):
        return self.dList

    def set_deletrex(self):
        self.set_init_vars()



class TradutorUE:
    def __init__(self):
        self.set_init_vars()
        self.d_Afl_ = dAfl_.TiouKey()
        self.dIOPx = dNewListORK()

        self.d_Afl_2 = dAfl_.TiouKey()


    def set_init_vars(self):

        self.dMudarIOX = ''
        self.dPalavras = ''
        self.dPalaworgs = [[] # index [0]
            , [] # palavra chr [1]
            , [] # palavra chr reserva [2]
            , [] # palavra chr teste [3]
            , [], # palvra chr reserva [4]
            [], # index qual escolher [5]
            ]

        self.dArgumenTix2 = ''

        self.dIndex2 = 0
        self.dIndex3 = 0

        self.dLisERK = []

        self.drtEPRSG = ''

        self.dIndexOP2 = 0
        self.dIndexOP3 = 0

    def set_Giu(self):
        self.d_Afl_.set_giu()

    def set_mudarTex(self, vMudart):
        self.dMudarIOX = str(vMudart)

        self.d_Afl_.set_mudar(self.dMudarIOX)

    # leitura
    def set_criptografar(self):
        for dtx in self.dMudarIOX:
            for dfix in self.d_Afl_.get_alls_wix(1):
                self.dIndex2 = self.dIndex3
                self.dIndex3 += 1
                if dtx == dfix:
                    #self.dArgumenTix2 += str(list(self.d_Afl_.get_alls_wix(5)[self.dIndex2][rdtE.randint(0, len(list(self.d_Afl_.get_alls_wix(5)[self.dIndex2])))]))

                    """
                    self.drtEPRSG = '[' + str(self.d_Afl_.get_alls_wix(5)[self.dIndex2]) + ']'

                    self.dIOPx.set_mudarTex(self.drtEPRSG)

                    self.dIOPx.set_ler()

                    self.dErtPX = self.dIOPx.get_ler()

                    self.dArgumenTix2 += self.dErtPX[rdtE.randint(self.dIndex2, (self.dIndex2+self.dIOPx.dIndexOP2))]

                    self.dIOPx.set_deletrex()

                    self.dIndex3 = 0
                    
                    """

                    self.d_Afl_2.dOProcesso_1 = '/' + self.d_Afl_.get_alls_wix(2)[self.dIndex2]

                    self.d_Afl_2.set_giu()

                    if bool(self.d_Afl_2.get_alls_wix(4) in dtx):
                        dIxTec = []
                        dIxStrDec = ''

                        try:
                            for dtsr in self.d_Afl_2.get_alls_wix(2)[self.dIndex2]:
                                if dIxStrDec == ',' or dIxStrDec == ';':
                                    dIxTec.append(dIxStrDec)
                                    dIxStrDec = ''
                                else:
                                    dIxStrDec += dtsr
                        finally:

                            self.dArgumenTix2 += dIxTec[rdtE.randint(0, len(dIxTec))]

                else:
                    self.dIndex3 = 0
                    if dtx == " ":
                        self.dArgumenTix2 += " "


    def get_criptografar(self):
        return self.dArgumenTix2

    #
    def set_traduzir(self):


        for dtx in self.dMudarIOX:
            for dfix in self.d_Afl_.get_alls_wix(4):
                self.dIndex2 = self.dIndex3
                self.dIndex3 += 1
                if dtx == bool(dfix[self.dIndex2]):
                    self.dArgumenTix2 += str(self.d_Afl_.get_alls_wix(1)[self.dIndex2])

                    self.dIndex3 = 0

                else:
                    self.dIndex3 = 0
                    if dtx == " ":
                        self.dArgumenTix2 += " "

    def get_traduzir(self):
        return self.dArgumenTix2


    def set_deleterX(self):
        self.dMudarIOX = ''
        self.dPalavras = ''
        self.dPalaworgs = [[]  # index [0]
            , []  # palavra chr [1]
            , []  # palavra chr reserva [2]
            , []  # palavra chr teste [3]
            , [],  # palvra chr reserva [4]
                           [],  # index qual escolher [5]
                           ]

        self.dArgumenTix2 = ''

        self.dIndex2 = 0
        self.dIndex3 = 0

        self.dLisERK = []

        self.drtEPRSG = ''

        self.dErtPX = []

        self.d_Afl_.set_deletrex()