import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.CriptKeyfria.AFL as dRopNanTEK

import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.CriptKeyfria.Tradetch as dRopTEC



dExt = dRopNanTEK.TiouKey()


'''

teoria da mini linguagem ou pelo nome -> "anolang":
    '/' iniciação de escopo, e de indentificador de caractere que vem depois.
    '/a' o caractere principal deste escopo é 'a'
    ---
    '=' é aqui que separa oque vem depois e oque vem antes do "="
    '/a = 10, 11' a associação de '10' e '11' é 'a', se vc colocar 'a' e colocar para criptografar, sairá 10 ou 11;
    ---
    ';' terminação de escopo; '/' abertura e ';' fechamento e ao mesmo tempo faz funções
    --- uso:
        /a = 10, 11;

'''

''' #apague esta 3 aspas simples para usar o modificador, a var modificador, mas apenas da linha 23

drst = str("""



""")

dExt.set_mudar(drst) # aqui vc simplesmente usa a var com as modificações

#apague o daqui tabém caso apague o de cima'''

dExt.set_giu() # inicializa a função

'''

1: associação complexa;
2: associação simples-associação
3:associação sem algo simples, que indique;
4: associação em que cada ',' é trocado por 'or' para usar em sua lógica
5° tá em teste. ainda terá outras funcionalidades; (tá quase funcionando)

'''


print(f'{dExt.get_alls_wix(5)[1]}5° parte') #veja que tem o número 1, mas aceita vários, é até 5
print(f'{dExt.get_alls_wix(1)}1° parte')
print(f'{dExt.get_alls_wix(4)}4° parte')
