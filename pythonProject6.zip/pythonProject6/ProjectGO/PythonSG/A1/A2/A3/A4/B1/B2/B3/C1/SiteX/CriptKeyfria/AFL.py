class TiouKey:
    def __init__(self):
        self.dtipo = 0
        self.dTransformador = ''
        self.dRecebedor = ''
        self.dRecebedorExtra = ''
        self.dRecebedorExtra2 = ''
        self.dAIgonarar = ''
        self.dignore = ['@', '!', 'ç', '><><', f'[{self.dAIgonarar}]', '', ' ']
        self.dEspaco = '|'
        self.dCaracteresEspeciais = []
        self.dDeCadaCaractre = []
        self.dAssociacaoDeCadaCaractere = []
        self.dAssociacaoDeCadaCaractere_2 = [] ###
        self.dOProcesso_1 = """
        
        {/w = 9891, 911, 119;
        /q = 1891, 150, 11, 1711;
        /e = 2919, 2999, 2666;
        /r = 3593, 3595, 3219;
        /t = 4590, 4112;
        /y = 5690, 5321;
        /u = 6738, 6199, 6781;
        /i = 7894, 7993, 7219;
        /o = 8901, 8904, 8171;
        /p = 918999, 9382789, 84993929;
        /a = 3477373, 78837, 477483;
        /s = 3838738, 383839, 47883;
        /r = 99849030, 849838, 847483;
        /d = 8847939383, 8487839383838, 48487833;
        /f = 478373783, 8447748474747, 48847474747477;
        /g = 11.111, 3899, 489393, 111111111111111;
        /h = 8888888, 88181818188181818188, 37737373737;
        /j = 10932092920;
        /k = 9999911111, 93939393939, 10983999283890;
        /l = 388398282, 83999, 3982281;
        /z = 1171771717, 8383789287, 1661611516;
        /x = 388737287262781, 8388878920999999, 4847478383888373828873883873787637873645362789999999;
        /c = 38893938382992229829119119, 4887378288228, 3888283829828282828;
        /v = 93889383292828292, 48838992828, 8388388383983828282888282828;
        /b = 7376546736363, 77783878383738, 73838383838;
        /n = 999.999.999.999.999.999.999.999.999, 994303990209020, 94449949;
        /m = 494949994844444444444444444444444444444444444499999999999999999999, 8444444444444444444444444444, 84444448488;
        /0 = rc9hr8cnny34gbc37bc4v2365vfrd5d5ed5fb23xbf632fvx5r23f6, rg74gb7x7gnqij9dg7g282u8yy7y7n839333333333333333333333333333333301111111111111111111111111111111111111111111111111111111111111111111111111, jbreibur crh8urh8rc h8yry8ry8bu uxhunuin icr;
        /1 = fkkkkkkkkkodkfoeeeeeeeeeeeeeeeeeemccccccccccccccccccccccccc8444444444444444444, wooooooooooooooooooooowwwwwwwwwwwwwwwwwwwwwwaaaaaaaaaaaaaawiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiifnnnnnnnnnnnnnnnnnnnnnnnnnnnnn, sççççççççççççççççççççççççççkffffffffffffffldddddddddddddddddsççççççççççalllllllllllllllllllllrnfvjfbrbrnronnroe;
        /( = knvibOPKJIOJJUEHUHWEY473387829OIBDCDY8O1KMN, BFNJKDOIUY4GBRNFMXKISUWY4GVRBDNJSI0APWLKMN4RBFHCUXI, FBNDJSIWUEYRGFBCNJXISUEYRGFBCNXJSHEGRTYDUXK;
        /) = GHNCMX,LSEIRHFBNCMXKLDRKTF,DKJRUTRFJDKOKRUTHFJDKOERIUTYHFJDKO;
        /- = ROORJNVJFNFNFJHFEBBFUBUBHbBUUYBBVvhuVYbbUVuvBIg7G7Yb8g67F65DrYUHVt6dr5C6Y, 8T7Vuvv7yvvvvbuvyt7bb7fcyvyt5eryvrDRCc6rdrctycrvyvTRCRVYTCRCTYVCrtcrtvy, vtcvc6rtvyctyc6rcycrt;
        
        },
        """.strip()
        self.fCont = 0
        self.fCont2 = 0
        self.fContExtra = 0
        self.fContExtra_2 = 0
        self.dExtraYu = False
        self.dAssociacaoDeCadaCaractere_2_extra2 = []
        self.dRecebedorExtra3 = ''

        # extra
        self.dAssociacaoDeCadaCaractere_3_ = []
        self.dAssociacaoDeCadaCaractere_3_extra2_or = []
        self.dAssociacaoDeCadaCaractere_3_extra2_list = []

        self.set_deletrex()

    def set_giu(self):
        for iukTt in range(len(self.dOProcesso_1)):
           self.dRecebedor += (self.dOProcesso_1[self.fCont])
           self.fCont += 1
           if self.fContExtra == 0:
                if '/' in self.dRecebedor:
                    self.dRecebedor = ''
                    self.fContExtra = 1
                    continue
                if '=' in self.dRecebedor:
                    self.dRecebedor = ''
                    self.fContExtra = 2
                    continue

           if self.fContExtra == 1:
               #self.dCaracteresEspeciais.append(self.dRecebedor)
               #self.dRecebedor = ''
               if '=' == self.dRecebedor and self.dJaFoiiTecBool == False:
                   self.dRecebedor = ''
                   self.fContExtra = 2
                   continue
               if ('' or ' ') in self.dRecebedor:
                   self.dRecebedor = ''
                   continue

               if self.dRecebedor == '"' or self.dRecebedor == "'":
                   try:
                        if self.dContTryx == 0:
                            self.dJaFoiiTecBool = True
                            #self.dContTryx += 1

                            if self.dRecebedor == '"':
                                self.dArgumetrex2_extra2 = '"'
                                self.dRecebedor = ''
                                self.dContTryx = 1
                                #self.dJaFoiiTecBool = True
                                continue
                            else:
                                self.dArgumetrex2_extra2 = "'"
                                self.dRecebedor = ''
                                self.dContTryx = 1
                                #self.dJaFoiiTecBool = True
                                continue
                        if self.dJaFoiiTecBool == True and self.dRecebedor == self.dArgumetrex2_extra2:
                            self.dRecebedor = ''
                            self.dJaFoiiTecBool = False
                            continue
                        '''
                        if self.dRecebedor != self.dArgumetrex2_extra2 and self.dJaFoiiTecBool == True:
                            self.dCaracteresEspeciais.append(self.dRecebedor)
                            self.dRecebedorExtra = self.dRecebedor
                            self.dRecebedorExtra = self.dRecebedor
                            self.dRecebedor = ''

                            continue
                        '''

                   finally:
                       if self.dJaFoiiTecBool == False:
                            self.dContTryx_extra2 = 0
                            self.dContTryx = self.dContTryx_extra2
                            self.dArgumetrex2_extra2 = ''

                            self.dRecebedor = ''


                            continue
               else:
                   self.dCaracteresEspeciais.append(self.dRecebedor)
                   self.dRecebedorExtra = self.dRecebedor
                   self.dRecebedor = ''

                   #op

                   #opend

                   continue
                    #self.fContExtra = 0


           if  self.fContExtra == 2:
               #if ';' in self.dRecebedor or '/' in self.dRecebedor:
               if '\n' in self.dRecebedor:
                   self.dRecebedor = ''
                   continue
               if ';' in self.dRecebedor and self.dJaFoiiTecBool == False: #era '/'
                    """
                    if ';' in self.dRecebedor:
                        self.fContExtra = 1
                
                    if '/' in self.dRecebedor:
                        # colocar 'self.dRecebedor = " "';
                        self.dRecebedor = ""
                        self.fContExtra = 1
                    """
                        ###
                    self.dRecebedor = ''
                    #self.dRecebedorExtra = ''
                    #self.fContExtra = 1 n recomendavel tirar disso de coment para codigo
                    self.dDeCadaCaractre.append(f"{self.dRecebedorExtra} = {self.dRecebedorExtra2};")
                    self.dAssociacaoDeCadaCaractere.append(self.dRecebedorExtra2)

                    #
                    self.dAssociacaoDeCadaCaractere_3_.append(self.dRecebedorExtra2)
                    #self.dAssociacaoDeCadaCaractere_3_extra2_or.append('"' + self.dRecebedorExtra2.replace(',', '" or "') + '"')
                    #self.dAssociacaoDeCadaCaractere_3_extra2_list.append(self.dRecebedorExtra2.replace(',', '"],["'))

                    self.dRecebedorExtra = ''
                    self.dRecebedorExtra2 = ''
                    self.dAssociacaoDeCadaCaractere_2_extra2.append(self.dAssociacaoDeCadaCaractere_2)
                    self.dAssociacaoDeCadaCaractere_2 = []

                    self.dListEIOP2_extra2.append(self.dRecebedor2Extra2)

                    self.dListEIOP2_extra3.append(self.dListEIOP2_extra2)
                    #
                    self.dAssociacaoDeCadaCaractere_3_extra2_or.append('"' + self.dRecebedor5Extra2_or2_extra2 + '"')
                    self.dAssociacaoDeCadaCaractere_3_extra3_or.append(self.dAssociacaoDeCadaCaractere_3_extra2_or)

                    self.dListEIOP2_extra2 = []
                    self.dAssociacaoDeCadaCaractere_3_extra2_or = []

                    self.dRecebedor2Extra2 = ''

                    continue
               if '/' in self.dRecebedor and self.dJaFoiiTecBool == False:
                   self.dRecebedor = ''
                   self.dRecebedorExtra2 = ''
                   self.dRecebedorExtra = ''

                   self.fContExtra = 1



                   continue
               if ('' or ' ') in self.dRecebedor:
                   self.dRecebedor = ''
                   continue
               if (',') in self.dRecebedor and self.dJaFoiiTecBool == False:
                    self.dRecebedorExtra2 += self.dRecebedor

                    self.dListEIOP2_extra2.append(self.dRecebedor2Extra2) #

                    self.dAssociacaoDeCadaCaractere_3_extra2_or.append(('"' + self.dRecebedor5Extra2_or2_extra2 + '" or '))

                    self.dRecebedor2Extra2 = ''
                    self.dRecebedor5Extra2_or2_extra2 = ''

                    self.dRecebedor = ''
                    self.dAssociacaoDeCadaCaractere_2.append(self.dRecebedorExtra3)
                    #self.dAssociacaoDeCadaCaractere_2_extra2.append(self.dAssociacaoDeCadaCaractere_2)
                    self.dRecebedorExtra3 = ''


               #dek
               if self.dRecebedor == '"' or self.dRecebedor == "'":
                   try:
                        if self.dContTryx == 0:
                            self.dJaFoiiTecBool = True
                            #self.dContTryx += 1

                            if self.dRecebedor == '"':
                                self.dArgumetrex2_extra2 = '"'
                                self.dRecebedor = ''
                                self.dContTryx = 1
                                #self.dJaFoiiTecBool = True
                                continue
                            else:
                                self.dArgumetrex2_extra2 = "'"
                                self.dRecebedor = ''
                                self.dContTryx = 1
                                #self.dJaFoiiTecBool = True
                                continue
                        if self.dJaFoiiTecBool == True and self.dRecebedor == self.dArgumetrex2_extra2:
                            self.dRecebedor = ''
                            self.dJaFoiiTecBool = False
                            continue
                        '''
                        if self.dRecebedor != self.dArgumetrex2_extra2 and self.dJaFoiiTecBool == True:
                            self.dCaracteresEspeciais.append(self.dRecebedor)
                            self.dRecebedorExtra = self.dRecebedor
                            self.dRecebedorExtra = self.dRecebedor
                            self.dRecebedor = ''

                            continue
                        '''

                   finally:
                       if self.dJaFoiiTecBool == False:
                            self.dContTryx_extra2 = 0
                            self.dContTryx = self.dContTryx_extra2
                            self.dArgumetrex2_extra2 = ''

                            self.dRecebedor = ''


                            continue
               #dekend


               else:
                   #self.dDeCadaCaractre.append(f"{self.dRecebedorExtra} = {self.dRecebedor}")
                   self.dRecebedorExtra2 += self.dRecebedor

                   self.dRecebedor2Extra2 += self.dRecebedor #

                    #
                   self.dRecebedor5Extra2_or2_extra2 += self.dRecebedor #

                   self.dRecebedor = ''

                   #ope

                   self.dRecebedorExtra3 = self.dRecebedorExtra2 #era += ###

                   #opend

                   #


                   continue

    def get_alls_wix(self, art):
        if art == 1:
            return self.dCaracteresEspeciais
        if art == 2:
            return self.dDeCadaCaractre
        if art == 3:
            return self.dAssociacaoDeCadaCaractere_3_
        if art == 4:
            return self.dAssociacaoDeCadaCaractere_3_extra3_or
        if art == 5:
            return self.dListEIOP2_extra3

    def set_mudar(self, dProcess):
        self.dOProcesso_1 = dProcess

    def set_deletrex(self):
        self.dtipo = 0
        self.dTransformador = ''
        self.dRecebedor = ''
        self.dRecebedorExtra = ''
        self.dRecebedorExtra2 = ''
        self.dAIgonarar = ''
        self.dignore = ['@', '!', 'ç', '><><', f'[{self.dAIgonarar}]', '', ' ']
        self.dEspaco = '|'
        self.dCaracteresEspeciais = []
        self.dDeCadaCaractre = []
        self.dAssociacaoDeCadaCaractere = []
        self.dAssociacaoDeCadaCaractere_2 = []  ###
        self.dOProcesso_1 = """

               {/w = 9891, 911, 119;
               /q = 1891, 1, 11, 1711;
               /e = 2919, 2999, 2666;
               /r = 3593, 3595, 3219;
               /t = 4590, 4112;
               /y = 5690, 5321;
               /u = 6738, 6199, 6781;
               /i = 7894, 7993, 7219;
               /o = 8901, 8904, 8171;
               /p = 918999, 9382789, 84993929;
               /a = 3477373, 78837, 477483;
               /s = 3838738, 383839, 47883;
               /r = 99849030, 849838, 847483;
               /d = 8847939383, 8487839383838, 48487833;
               /f = 478373783, 8447748474747, 48847474747477;
               /g = 11.111, 3899, 489393, 111111111111111;
               /h = 8888888, 88181818188181818188, 37737373737;
               /j = 10932092920;
               /k = 9999911111, 93939393939, 10983999283890;
               /l = 388398282, 83999, 3982281;
               /z = 1171771717, 8383789287, 1661611516;
               /x = 388737287262781, 8388878920999999, 4847478383888373828873883873787637873645362789999999;
               /c = 38893938382992229829119119, 4887378288228, 3888283829828282828;
               /v = 93889383292828292, 48838992828, 8388388383983828282888282828;
               /b = 7376546736363, 77783878383738, 73838383838;
               /n = 999.999.999.999.999.999.999.999.999, 994303990209020, 94449949;
               /m = 494949994844444444444444444444444444444444444499999999999999999999, 8444444444444444444444444444, 84444448488;
               /0 = rc9hr8cnny34gbc37bc4v2365vfrd5d5ed5fb23xbf632fvx5r23f6, rg74gb7x7gnqij9dg7g282u8yy7y7n839333333333333333333333333333333301111111111111111111111111111111111111111111111111111111111111111111111111, jbreibur crh8urh8rc h8yry8ry8bu uxhunuin icr;
               /1 = fkkkkkkkkkodkfoeeeeeeeeeeeeeeeeeemccccccccccccccccccccccccc8444444444444444444, wooooooooooooooooooooowwwwwwwwwwwwwwwwwwwwwwaaaaaaaaaaaaaawiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiifnnnnnnnnnnnnnnnnnnnnnnnnnnnnn, sççççççççççççççççççççççççççkffffffffffffffldddddddddddddddddsççççççççççalllllllllllllllllllllrnfvjfbrbrnronnroe;
               /( = knvibOPKJIOJJUEHUHWEY473387829OIBDCDY8O1KMN, BFNJKDOIUY4GBRNFMXKISUWY4GVRBDNJSI0APWLKMN4RBFHCUXI, FBNDJSIWUEYRGFBCNJXISUEYRGFBCNXJSHEGRTYDUXK;
               /) = GHNCMX,LSEIRHFBNCMXKLDRKTF,DKJRUTRFJDKOKRUTHFJDKOERIUTYHFJDKO;
               /- = ROORJNVJFNFNFJHFEBBFUBUBHbBUUYBBVvhuVYbbUVuvBIg7G7Yb8g67F65DrYUHVt6dr5C6Y, 8T7Vuvv7yvvvvbuvyt7bb7fcyvyt5eryvrDRCc6rdrctycrvyvTRCRVYTCRCTYVCrtcrtvy, vtcvc6rtvyctyc6rcycrt;

               },
               """.strip()
        self.fCont = 0
        self.fCont2 = 0
        self.fContExtra = 0
        self.fContExtra_2 = 0
        self.dExtraYu = False
        self.dAssociacaoDeCadaCaractere_2_extra2 = []
        self.dRecebedorExtra3 = ''

        # extra
        self.dAssociacaoDeCadaCaractere_3_ = []
        self.dAssociacaoDeCadaCaractere_3_extra2_or = []
        self.dAssociacaoDeCadaCaractere_3_extra2_list = []

        self.dAssociacaoDeCadaCaractere_3_extra3_or = []

        self.dListEIOP2 = []
        self.dListEIOP2_extra2 = []
        self.dListEIOP2_extra3 = []

        self.dRecebedor2Extra2 = ''

        self.dRecebedor5Extra2 = ''
        self.dRecebedor5Extra2_or2_extra2 = ''

        self.dJaFoiiTecBool = False
        self.dJaFoiiTecBool_extra2 = False

        self.dArgumetrex2 = ''
        self.dArgumetrex2_extra2 = ''

        self.dContTryx = 0
        self.dContTryx_extra2 = 0

        self.dTypeAspas2 = 0
        self.dTypeAspas2_extra2 = 0


        self.dVarTesteStringTek = ''


#
"""
if True:
    drt = TiouKey()
    drt.set_giu()
    print(drt.get_alls_wix(1))
    print(drt.get_alls_wix(2))
    print()
    #print(drt.dRecebedor)
    print(drt.dOProcesso_1[20])
"""