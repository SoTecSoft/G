import ProjectGO.PythonSG.A1.A2.A3.A4.B1.B2.B3.C1.SiteX.CriptKeyfria.AFL as TDSA
import random as  rdmT

class Tradutor_X:
    def __init__(self):
        self.dGfl = TDSA.TiouKey()
        self.dPalavras = ''
        self.dCont = 0
        self.dCont2 = 0
        self.dCont3 = 0
        self.dKiu = ''
        self.dKiuStr = ''
        self.strG2X = []
        self.strG3X = []
        self.dKiuStr_2 = ''
        self.dKiuStr_3 = ''
        self.dKiuStr_4 = ''
        self.strG4X = []
        self.dContPX = 0
        self.dContPX2 = 0

        self.dContOPX3 = []
        self.dKiuStr_5 = []
        self.dRdm_A2 = 0
        self.dKiuStr_5_extra2 = []
        self.dAleator = 0
        self.dPara_Aleator = False



    def iuDizo(self, fKiu):
        self.dKiu = fKiu
        for dfx in self.dKiu:
            if dfx == '=':
                if self.dCont3 == 0:
                    self.dCont3 += 1
            else:
                if self.dCont3 == 1:
                    self.dKiuStr += dfx


    def set_arguwords(self, palavras):
        self.dPalavras = palavras


    def traduzirParaAlgoritimo(self):
        for dxt in self.dPalavras:
            self.dCont2 = 0
            for dtrxtop in self.dGfl.dDeCadaCaractre:
                self.dCont = self.dCont2
                self.dCont2 += 1
                #if dxt == dtrxtop:
                if dtrxtop in dxt:
                    """
                    self.iuDizo(dtrxtop)
                    self.strG2X.append(self.dKiuStr)
                    self.strG3X.append(self.dPalavras)
                    """
                    self.dKiuStr_3 += '+'
                    self.dKiuStr_2 += dxt
                    self.dKiuStr_3 += (self.dGfl.dAssociacaoDeCadaCaractere[self.dCont])
                    self.dKiuStr_3 += '+'
                    self.dKiuStr_4 += self.dGfl.dCaracteresEspeciais[self.dCont]

                    ###

                    self.dKiuStr_5.append(self.dGfl.dAssociacaoDeCadaCaractere_2_extra2[self.dCont])
                    self.dContOPX3.append(self.dCont)


                if dxt == ' ':
                    self.dKiuStr_4 += ' '

    def set_niwAle(self, dXAle):
       self.dPara_Aleator = dXAle


    def get_keywords(self, atIdex):
        self.traduzirParaAlgoritimo()
        self.strG2X.append(self.dKiuStr_2)
        self.strG3X.append(self.dKiuStr_3)
        self.strG4X.append(self.dKiuStr_4)

        #self.dContPX += self.dContPX2
        #self.dContPX2 += 1
        if atIdex == 1:
            return self.strG2X[self.dContPX]
        if atIdex == 2:
            return self.strG3X[self.dContPX]
        if atIdex == 3:
            return self.strG4X[self.dContPX]
        if atIdex == 4:
            """
            for dTruk in self.dContOPX3:
                self.dKiuStr_5_extra2.append(self.dKiuStr_5)
            """
            if self.dPara_Aleator == False:
                return self.dKiuStr_5
            else:
                aExG = 0
                for dFGXTT in self.dKiuStr_5[self.dContPX]:
                    aExG += 1
                self.dAleator = rdmT.randint(0, aExG)
                return self.dKiuStr_5[self.dContPX][self.dAleator]


    def set_enssecialInit_A1(self):
        self.dGfl.set_giu()

    def set_mudarArgumentsGeral(self, dtoopG):
        self.dGfl.set_mudar(dtoopG)

    def set_deleteOPNew(self):
        #self.dGfl = TDSA.TiouKey()
        self.dPalavras = ''
        self.dCont = 0
        self.dCont2 = 0
        self.dCont3 = 0
        self.dKiu = ''
        self.dKiuStr = ''
        self.strG2X = []
        self.strG3X = []
        self.dKiuStr_2 = ''
        self.dKiuStr_3 = ''
        self.dKiuStr_4 = ''
        self.strG4X = []
        self.dContPX = 0
        self.dContPX2 = 0

        self.dContOPX3 = []
        self.dKiuStr_5 = []
        self.dRdm_A2 = 0
        self.dKiuStr_5_extra2 = []
        self.dAleator = 0